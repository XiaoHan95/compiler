#include "node.h"
#include "compiler.tab.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "CalcAttri.h"
/*
 	global line//error information
 	global typesize
 	global TypeOrder = 2;
 	global AccumulatedSize//change at the same time when typesize change, and set their value the same
 	global InnerSituationVectorHead = NULL, InnerSituationVectorEnd = NULL, dimention = 0,
 	global ArgNum = 0;
 	global NestedStruct = 0;
 	7777:global FunNum = 0; compstlevel = -1;//when in compst ++, outof compst --
 		 global InFun = 0;//if in the function, then infun is 1
 	1111:global vhead = NULL;//this store the global variables chain head
 	6666:global checkdimention;//used to check the array validability
 	6666:some added elements in tree node
 	6666:global checkargnum;//used to check the arg num consistency
 	enum*/

 	//scope: do not need them,cuz the deflist and extdeflist stack will solve this

void visit(pNODE root)
{
    if(root==NULL)
        return;
    switch(root->nodetype)
   	{
   		case(PROGRAM_type):
//   			1111:set son extdeflist pointerchain = NULL
//   			set root program offset = 0;
//   			set son extdeflist offset = 0;
//   			visit(son extdeflist)
//   			pass root program offset = son extdeflist offset
//   			end
            root->son1->pointer.pvar = NULL;
            root->offset = 0;
            root->son1->offset = 0;
            visit(root->son1);
            root->offset = root->son1->offset;
            break;
   		case(EXTDEFLIST_type):
//   			{when extdeflist : empty
//   				end
//   			}
//   			{when extdeflist : extdef extdeflist
//   				1111:set son extdef pointerchain = root extdeflist pointerchain
//   				set son extdef offset = root extdeflist offset
//   				visit(son extdef)
//   				passtobrother: set son extdeflist offset = son extdef offset
//   				1111:passtobrother : set son extdeflist pointerchain = son extdef pointerchain
//   				visit(son extdeflist)
//   				pass: root extdeflist offset = son extdeflist offset
//   				1111: pass root extdeflist pointerchain = son extdeflist pointerchain
//   				end
//   			}
            if(root->ProductionType == EXTDEFLIST_empty)
   			{
   				break;
   			}
   			else
            {
                root->son1->pointer.pvar = root->pointer.pvar;
   				root->son1->offset = root->offset;
   				visit(root->son1);
   				root->son2->offset = root->son1->offset;
   				root->son2->pointer.pvar = root->son1->pointer.pvar;
   				visit(root->son2);
   				root->offset = root->son2->offset;
   				root->pointer.pvar = root->son2->pointer.pvar;
   				break;
            }
            break;
   		case(EXTDEF_type):
            if(root->ProductionType == EXTDEF1_pro)
   			{//when extdef : specifier extdeclist;
//   			 	visit(son specifier)
//   			 	1111:set son extdeclist pointerchain = root extdef pointerchain
//   			 	set son extdeclist offset = root extdef offset
//   			 	visit(son extdeclist)
//   			 	pass: root extdef offset = son extdeclist offset
//   			 	1111:pass: root extdef pointer chain = son extdeclist pointer chain//this is global one
//          		1111:cancel//add entry to global variable array list
//          		1111:vhead = root extdef pointerchain//the global var head information
//   			 	end
   			 	visit(root->son1);
   			 	root->son2->pointer.pvar = root->pointer.pvar;
   			 	root->son2->offset = root->offset;
   			 	visit(root->son2);
   			 	root->offset = root->son2->offset;
   			 	root->pointer.pvar = root->son2->pointer.pvar;
                vhead = root->pointer.pvar;
   			 	break;
   			}
            else if(root->ProductionType == EXTDEF2_pro)
   			{//when extdef : specifier ;
   				//0000:
//   				visit(son specifier);
//   				end//do not change the offset by any means
                visit(root->son1);
                break;
   			}
   			else
   			{//when extdef : specifier fundec compst
//   				1111:because the transport between brother,the root extdef has the global variable
//   					 chain head information
//   				ArgNum = 0;
//   				7777:InFun = 1;
//   				visit(son specifier)
//   				1111:set son fundec pointerchain = NULL
//   				visit(son fundec)
//   				1111:passtobrother: son compst pointerchain = son fundec pointerchains
//   				passtobrother: son compst offset = son fundec offset
//   				visit(son compst)
//   				1111://because we have not change the pointerchain of extdef,it is save for global variable
//   				7777:InFun = 0;//outof the function
//   				end
                ArgNum = 0;
                InFun = 1;
                visit(root->son1);
                root->son2->pointer.pvar = NULL;
                visit(root->son2);
                root->son3->pointer.pvar = root->son2->pointer.pvar;
                root->son3->offset = root->son2->offset;
                visit(root->son3);
                InFun = 0;
                break;
   			}
   			break;
   		case(EXTDECLIST_type):
            if(root->ProductionType == EXTDECLIST2_pro)
   			{//when extdeclist: vardec,extdeclist
//   				1111:set son vardec pointerchain = root extdeclist pointerchain
//   				set son vardec offset = root extdeclist offset
//   				visit(son vardec)
//   				passtobrother: son extdeclist offset = son vardec offset
//   				1111:passtobrother : son extdeclist pointerchain = son vardec pointerchain
//   				visit(son extdeclist)
//   				pass: set root extdeclist offset = son extdeclist offset;
//   				1111:pass root extdeclist pointerchain = son extdeclist pointerchain
//   					cancel//pass: merge the son vardec chain and son extdeclist chain
//   				end
                root->son1->pointer.pvar = root->pointer.pvar;
                root->son1->offset = root->offset;
                visit(root->son1);
                root->son3->offset = root->son1->offset;
                root->son3->pointer.pvar = root->son1->pointer.pvar;
                visit(root->son3);
                root->offset = root->son3->offset;
                root->pointer.pvar = root->son3->pointer.pvar;
                break;
   			}
   			else
   			{//when extdeclist:vardec
//   				1111:set son vardec pointerchain = root extdeclist pointerchain
//   				set son vardec offset = root extdeclist offset
//   				visit(son vardec)
//   				pass: set root extdeclist offset = son extdeclist offset;
//   				1111:pass: set root extdeclist pointerchain = son vardec pointerchain
//   				end
                root->son1->pointer.pvar = root->pointer.pvar;
                root->son1->offset = root->offset;
                visit(root->son1);
                root->offset = root->son1->offset;
                root->pointer.pvar =root->son1->pointer.pvar;
                break;
   			}
   			break;
   		case(FUNDEC_type):
   		if(root->ProductionType == FUNDEC1_pro)
   		{//when fundec:id (varlist) 1
//   			3333:lookupinfunctiontable(ID)
//   				found:rename overlap problem
//   				aftererror
//   			notfound:
//   			create local function entry
//   			7777: FunNum++;
//   			set functin entry return type = TypeOrder
//   			set function name = strcpy ID
//   			set function line
//   			add local function to global
//   			set son varlist offset = 0
//   			1111:set son varlist pointerchain = root fundec pointerchain
//   			visit(son varlist)
//   			pass: root fundec offset = son varlist offset
//   			set function memberpointer = son varlist
//   			set function ArgNum = ArgNum
//   			1111:pass: root fundec pointerchain = son varlist pointerchain
//   			//we do not need to clear the argnum,because every time we enter the function we clear it
//   			//automatically
//   		    	end
            pFUNCTION result = SearchInFunctionTable(root->info.ID,fhead);
            if(result != NULL)
            {
                printf("Error type 4 at line %d:Redifined function\"%s\"\n",root->line,root->info.ID);
                exit(-3);
            }
            else
            {
                pFUNCTION flocal = (pFUNCTION)malloc(sizeof(FUNCTION));
                flocal->next = NULL;
                FunNum++;
                if(!flocal)
                {
                    puts("malloc failed:CalcAttri.c line 207");
                    exit(-1);
                }
                flocal->RetureType = TypeOrder;
                if(strcpy(flocal->name,root->info.ID) == NULL)
                {
                    puts("strcpy failed:CalcAttri.c line 213");
                    exit(-1);
                }
                flocal->line = root->line;
                if(fhead == NULL)
                {
                    fhead = flocal;
                }
                else
                {
                    pFUNCTION temp = fhead;
                    fhead = flocal;
                    fhead->next = temp;
                }
                root->son1->offset = 0;
                root->son1->pointer.pvar = root->pointer.pvar;
                visit(root->son1);
                root->offset = root->son1->offset;
                flocal->ParameterPointer = root->son1->pointer.pvar;
                flocal->ParameterNum = ArgNum;
                root->pointer.pvar = root->son1->pointer.pvar;
            }
            break;
   		}
        else
   		{//when fundec:id() 2
//   			3333:lookupinfunctiontable(ID)
//   			found:rename overlap problem
//   			aftererror
//   			notfound:
//   			create local function entry
//   			7777:FunNum++
//   			set functin entry return type = TypeOrder
//   			set function name = strcpy ID
//   			set function line
//   			add local function to global
//   			set root function memberpointer  = NULL
//   			set root function argnum = 0;
//   			pass: root function offset = 0;
//   			1111:pass:root fundec pointerchain = NULL;
            pFUNCTION result = SearchInFunctionTable(root->info.ID,fhead);
            if(result != NULL)
            {
                printf("Error type 4 at line %d:Redifined function\"%s\"\n",root->line,root->info.ID);
                exit(-3);
            }
            else
            {
                pFUNCTION flocal = (pFUNCTION)malloc(sizeof(FUNCTION));
                flocal->next = NULL;
                FunNum++;
                if(!flocal)
                {
                    puts("malloc failed:CalcAttri.c line 266");
                    exit(-1);
                }
                flocal->RetureType = TypeOrder;
                if(strcpy(flocal->name,root->info.ID) == NULL)
                {
                    puts("strcpy failed:CalcAttri.c line 272");
                    exit(-1);
                }
                flocal->line = root->line;
                if(fhead == NULL)
                {
                    fhead = flocal;
                }
                else
                {
                    pFUNCTION temp = fhead;
                    fhead = flocal;
                    fhead->next = temp;
                }
                root->offset = 0;
                flocal->ParameterPointer = NULL;
                flocal->ParameterNum = 0;
                root->pointer.pvar = NULL;
            }
            break;
   		}
        break;

   		case(VARLIST_type):
            if(root->ProductionType == VARLIST1_pro)
   			{//when varlist: paramdec , varlist
//   				set son paramdec offset = root varlist offset
//   				1111:set son paramdec pointerchain = root varlist pointerchain
//   				visit(son paramdec)
//   				1111:passtobrother: son varlist pointerchain = son paramdec pointerchain
//   				passtobrother: son varlist offset = son paramdec offset
//   				visit(son varlist)
//   				pass: root varlist offset = son varlist offset
//   				//the paramdec son has only one entry,so it is easier to deal with
//   				//and by adding the varlist chain to paramdec chain, we form the parameter sequence
//   				1111:pass: root varlist pointerchain = son varlist pointerchain
//   					 cancel//pass: root varlist chainpointer = merge son paramdec chainpointer and son varlist chainpointer
//   				end
                root->son1->offset = root->offset;
                root->son1->pointer.pvar = root->pointer.pvar;
                visit(root->son1);
                root->son3->pointer.pvar =root->son1->pointer.pvar;
                root->son3->offset = root->son1->offset;
                visit(root->son3);
                root->offset = root->son3->offset;
                root->pointer.pvar = root->son3->pointer.pvar;
                break;
			}
			else
			{//when varlist : paramdec
//				1111:set son paramdec pointerchain = root varlist pointerchain
//				set son paramdec offset = root varlist offset
//				visit(son paramdec)
//				pass: root varlist offset = son paramdec offset
//				1111:pass: root varlist chainpointer = son paramdec chainpointer
//				end
                root->son1->pointer.pvar = root->pointer.pvar;
                root->son1->offset = root->offset;
                visit(root->son1);
                root->offset = root->son1->offset;
                root->pointer.pvar = root->son1->pointer.pvar;
                break;
			}
			break;

		case(PARAMDEC_type):
//			set ArgNum increase by one++
//			visit(son specifier)
//			1111:set son vardec pointerchain = root paramdec pointerchain
//			set son vardec offset = root paramdec offset
//			visit(son vardec)
//			pass: root paramdec offset = son vardec offset
//			1111:pass: root paramdec chainpointer = son vardec chainpointer
//			end
            ArgNum++;
            visit(root->son1);
            root->son2->pointer.pvar = root->pointer.pvar;
            root->son2->offset = root->offset;
            visit(root->son2);
            root->offset = root->son2->offset;
            root->pointer.pvar = root->son2->pointer.pvar;
            break;
   		case(COMPST_type):
//   			1111:set son deflist pointerchain = root compst pointerchain
//   			7777:compstlevel++;//so the defined struct has scope and invisualbility
//   							   //so the struct defined in the parameter list is not in the compst
//   							   //but even their compstlevel scope different from each other,
//   							   //one for -1 one for 0.they are global in the function level
//                   compstnum++;
//   			set son deflist offset = root compst offset;
//   			visit(son deflist)
//   			4444:push deflist pointerchain into stackofvariables
//   			//even the function parameter will be pushed in because of the transportation made
//   			//the compst inherit the fundec parameter chain information
//   			pass: root compst offset = son deflist offset
//  			//we do not need to set son stmtlist offset
//   			visit(son stmtlist)
//   			7777:compstlevel--;
//   			4444:pop deflist pointerchain outof stack
//   			end
            root->son1->pointer.pvar = root->pointer.pvar;
            CompstLevel++;
            CompstNum++;
            root->son1->offset = root->offset;
            visit(root->son1);
            pDEFLISTSTACK temp = stackHead;
            stackHead = (pDEFLISTSTACK)malloc(sizeof(DEFLISTSTACK));
            if(!stackHead)
            {
                puts("malloc failed:CalcAttri.c line 379");
                exit(-1);
            }
            stackHead->next = temp;
            stackHead->DeflistChainHead = root->son1->pointer.pvar;
            root->offset = root->son1->offset;
            visit(root->son2);
            CompstLevel--;
            pDEFLISTSTACK temp1 = stackHead;
            stackHead = stackHead->next;
            free(temp1);
            break;
   			//visit other stmtlist, because the compst may be nested in them and we need to get them
   		case(STMTLIST_type):
            if(root->ProductionType == STMTLIST_empty)
   			{//when empty
//   				end
                break;
   			}
   			else
   			{//when stmtlist : stmt stmtlist
//   				visit(son stmt)
//   				visit(son stmtlist)
//   				end
                visit(root->son1);
                visit(root->son2);
                break;
   				//both do not need set offset
   			}
   			break;

   		case(STMT_type):
            if(root->ProductionType == STMT2_pro)
   			{//when stmt:compst pro2
//   				1111:set son compst pointerchain = NULL;//free from outer name worries
//   				set son compst offset = 0;
//   				visit(son compst)
//   				end
                root->son1->pointer.pvar = NULL;
                root->son1->offset = 0;
                visit(root->son1);
                break;
   			}
   			else if(root->ProductionType == STMT1_pro)
   			{//when stmt:exp; pro1
//   				visit(son exp)
//   				if(son exp ->valuetype == array_type)
//   					error:array not allowed!
//   					aftererror
//   				end
                visit(root->son1);
                if(root->son1->ValueType == array_type)
                {
                    printf("Error type 18 at line %d:array type is not allowed for expression\n",root->line);
                    exit(-3);
                }
                break;
   			}
            else if(root->ProductionType == STMT3_pro)
   			{//when stmt:return exp; pro3
   				//because the recent function entry is in the fhead and is the first
   				//i can have easy access to it using fhead
//   				visit(son exp)
//   				if(son exp->valuetype == array_type)
//   					error:array not allowed!
//   					aftererror
//   				if(son exp->TypeOrder != fhead->returntype)
//   					error:return type mismatch!
//   					aftererror
//   				end
                visit(root->son2);
                if(root->son2->ValueType == array_type)
                {
                    printf("Error type 18 at line %d:array type is not allowed for expression\n",root->line);
                    exit(-3);
                }
                if(root->son2->TypeOrder != fhead->RetureType)
                {
                    printf("Error type 8 at line %d:Type mismatched for return\n",root->line);
                    exit(-3);
                }
                break;
   			}
            else if(root->ProductionType == STMT4_pro)
   			{//when stmt:if(exp) stmt pro4
//   				visit(son exp)
//   				if(son exp -> valuetype == array_type)
//   					error:array not allowed
//   					aftererror
//   				if(son exp ->TypeOrder != 0)
//   					error:boolean not allowed for non int type!
//   					aftererror
//   				visit(son stmt)
//   				end
                visit(root->son1);
                if(root->son1->ValueType == array_type)
                {
                    printf("Error type 18 at line %d:array type is not allowed for expression\n",root->line);
                    exit(-3);
                }
                if(root->son1->TypeOrder != 0)
                {
                    printf("Error type 7 at line %d: Type mismatched for boolean condition\n",root->line);
                    exit(-3);
                }
                visit(root->son2);
                break;
   			}
            else if(root->ProductionType == STMT5_pro)
   			{//when stmt:if(exp) stmt else stmt pro5
//   				visit(son exp)
//   				if(son exp -> valuetype == array_type)
//   					error:array not allowed
//   					aftererror
//   				if(son exp ->TypeOrder != 0)
//   					error:boolean not allowed for non int type!
//   					aftererror
//   				visit(son stmt)
//   				visit(son stmt)
                visit(root->son1);
                if(root->son1->ValueType == array_type)
                {
                    printf("Error type 18 at line %d:array type is not allowed for expression\n",root->line);
                    exit(-3);
                }
                if(root->son1->TypeOrder != 0)
                {
                    printf("Error type 7 at line %d: Type mismatched for boolean condition\n",root->line);
                    exit(-3);
                }
                visit(root->son2);
                visit(root->son3);
                break;
   			}
            else
   			{//when stmt:while(exp) stmt pro6
//   				visit(son exp)
//   				if(son exp -> valuetype == array_type)
//   					error:array not allowed
//   					aftererror
//   				if(son exp ->TypeOrder != 0)
//   					error:boolean not allowed for non int type!
//   					aftererror
//   				visit(son stmt)
//   				end
                visit(root->son1);
                if(root->son1->ValueType == array_type)
                {
                    printf("Error type 18 at line %d:array type is not allowed for expression\n",root->line);
                    exit(-3);
                }
                if(root->son1->TypeOrder != 0)
                {
                    printf("Error type 7 at line %d: Type mismatched for boolean condition\n",root->line);
                    exit(-3);
                }
                visit(root->son2);
                break;
   			}
   			break;

    	case(SPECIFIER_type):
            if(root->ProductionType == TYPEINT_pro)
    		{
                TypeSize = 4;
                AccumulatSize = 4;
                TypeOrder = 0;
                break;
    		}
//    			update typesize = AccumulatedSize = 4;
//    			update TypeOrder
            else if(root->ProductionType == TYPEFLOAT_pro)
    		{
                TypeSize = 4;
                AccumulatSize = 4;
                TypeOrder = 1;
                break;
    		}
    		else
    		{   //visit(son structspecifier)
//    			end
                visit(root->son1);
                break;
    		}
    		break;

    	case(STRUCTSPECIFIER_type):
            if(root->ProductionType == STRUCTSPECIFIER2_pro)
    		{//when structspecifier: struct  tag
//    			7777:pResult = lookupinsturcttable(tag)
//              notfound: error undefined structure
//              found:
//    			if(InFun == 0)
//    				//when outside
//    				if(pResult->funnum scope != 0)
//    					error:invisible struct!
//    					aftererror
//    				else
//    					update typesize  = lookupinsturcttable(tag).size
//    					update TypeOrder = lookupinsturcttable(tag).TypeOrder
//    					update AccumulateSize = typesize
//    			if(InFun != 0)
//    				//when in function
//    				if( (pResult->scope FunNum != FunNum)&&(pResult->scope FunNum!=0) )  ||
//    					error:invisible struct!
//    					aftererror
//                  else if(pResult->scope compstlevel>compstlevel)
//                        error:invisible struct!
//                        aftererror
//                  else if((pResult->scope compstlevel ==compstlevel )&&(pResult ->scope compstnum != compstnum))
//                        error:invisible struct!
//                        aftererror
//    				else
//    					update typesize  = lookupinsturcttable(tag).size
//    					update TypeOrder = lookupinsturcttable(tag).TypeOrder
//    					update AccumulateSize = typesize
//    			end
                pSTRUCTTYPE result = SearchInStructTable(root->son2->info.ID,shead);
                if(!result)
                {
                    printf("Error type 17 at line %d: Undefined or invisible structure \"%s\"\n",root->son2->line,root->son2->info.ID);
                    exit(-3);
                }
                if(InFun == 0)
                {
                    if(result->funscope != 0)
                    {
                        printf("Error type 17 at line %d: Undefined or invisible structure \"%s\"\n",root->son2->line,root->son2->info.ID);
                        exit(-3);
                    }
                }
                if(InFun ==1)
                {
                    if( (result->funscope != FunNum)&&(result->funscope!=0) )
                    {
                        printf("Error type 17 at line %d: Undefined or invisible structure \"%s\"\n",root->son2->line,root->son2->info.ID);
                        exit(-3);
                    }
                    else if(result->compstscope > CompstLevel)
                    {
                        printf("Error type 17 at line %d: Undefined or invisible structure \"%s\"\n",root->son2->line,root->son2->info.ID);
                        exit(-3);
                    }
                    else if((result->compstscope == CompstLevel)&&(result->compstnumscope != CompstNum))
                    {
                        printf("Error type 17 at line %d: Undefined or invisible structure \"%s\"\n",root->son2->line,root->son2->info.ID);
                        exit(-3);
                    }
                }
                TypeSize = result->size;
                TypeOrder = result->order;
                AccumulatSize = TypeSize;
                break;
    		}
    		else
    		{//when structspecifier:struct OptTag {deflist}
//    			2222:lookupinsturcttable(OptTag) //check the rename
//    				found:rename problem//line known
//    				aftererror
//    			notfound:
//    			create local new entry
//    			NestedStruct++;
//    			7777:if(InFun == 1)
//    				set local scope = FunNum
//    				set local scope = compstlevel
//                  set local scope = compstnum
//    			7777:else
//    				set local scope = 0;
//    				set local scope = -1;//when scope = 0 ,the second parameter we do not care\
//                  set local scope = -1;//when scope = 0; the third parrameter we do not care
//    			set local name
//    			set local TypeOrder
//    			update TypeOrder by one++
//    			1111:add local new entry to global//be aware the following information was
//    											  //added via local entry pointer.
//    			1111:set son deflist pointerchain = NULL
//    			set son deflist offset = 0
//    			visit(son deflist)
//    			set local size = son deflist offset
//    			set local memberpointer = son deflist pointer chain
//    			update typesize = local size
//    			update TypeOrder = local TypeOrder
//    			update AccumulatedSize = typesize
//    			NestedStruct--;
//    			end
                pSTRUCTTYPE result = SearchInStructTable(root->son1->info.ID,shead);
                if(result)//found
                {
                    printf("Error type 16 at line %d: Redefined structure \"%s\"\n",root->son1->line,root->son1->info.ID);
                    exit(-3);
                }
                pSTRUCTTYPE slocal = (pSTRUCTTYPE)malloc(sizeof(STRUCTTYPE));
                slocal->next = NULL;
                if(!slocal)
                {
                    puts("malloc failed:CalcAttri.c line 656");
                    exit(-1);
                }
                NestedStructNum++;
                if(InFun == 0)
                {
                    slocal->funscope = 0;
                    slocal->compstscope = -1;
                    slocal->compstnumscope = CompstNum;
                }
                else
                {
                    slocal->funscope = 1;
                    slocal->compstscope = CompstLevel;
                    slocal->compstnumscope = CompstNum;
                }
                if(root->son1->ProductionType == OPTTAG_empty)
                {
                    int i = 0;
                    for(i = 0; i <32; i++)
                    {
                        slocal->name[i] = '\0';
                    }
                    slocal->line = -1;//the anonymous structure's line is -1
                                      //the error report decide to the variable that use it
                                      //because anonymous has no rename problem
                }
                else
                {
                    if(NULL == strcpy(slocal->name,root->son1->info.ID))
                    {
                        puts("strcpy failed.CalcAttri.c line 321");
                        exit(-1);
                    }
                    slocal->line = root->son1->line;//the OptTag line infor
                }
                slocal->order = StructType++;
                if(!shead)
                {
                    shead = slocal;
                }
                else
                {
                    pSTRUCTTYPE temp = shead;
                    shead = slocal;
                    shead->next = temp;
                }
                root->son2->pointer.pvar = NULL;
                root->son2->offset = 0;
                visit(root->son2);
                slocal->size = root->son2->offset;
                slocal->MemberPointer = root->son2->pointer.pvar;
                TypeSize = slocal->size;
                AccumulatSize = TypeSize;
                TypeOrder = slocal->order;
                NestedStructNum--;
                break;
    		}
    		break;

    	case(DEFLIST_type):
            if(root->ProductionType == DEFLIST_pro)
    		{//when deflist: def and deflist
//    			set son def offset = root deflist offset
//    			1111:set son def pointerchain = root deflist pointerchain
//    			visit(son def)
//    			passtobrother: son deflist offset = son def offset
//    			1111:passtobrother: son deflist pointerchain = son def pointerchain
//    			visit(son deflist)
//    			pass: root deflist offset = son deflist offset
//    			1111: pass: root deflist chain pointer = son deflist pointerchain
//    			1111:cancel//pass: root deflist chain pointer = merge two son chain pointer
//    			end
                root->son1->offset = root->offset;
                root->son1->pointer.pvar = root->pointer.pvar;
                visit(root->son1);
                root->son2->offset = root->son1->offset;
                root->son2->pointer.pvar = root->son1->pointer.pvar;
                visit(root->son2);
                root->offset = root->son2->offset;
                root->pointer.pvar = root->son2->pointer.pvar;
                break;
    		}
    		else
    		{//when deflist: empty
//    			1111: end//do nothing,cuz the pointer chain and offset has just received from brother
//    			1111: cancel //pass: root deflist chain pointer = NULL;
//    			//the offset does not need managing
//    			//do nothing
                break;
//    			end
    		}
    		break;

    	case(DEF_type):
//    		visit(son specifier) , get typesize and TypeOrder
//    		set AccumulatedSize = typesize//change at the same time
//    		1111:set son declist pointerchain = root def pointerchain
//    		set son declist offset = root def offset
//    		visit(son declist)
//    		pass: root def offset = son declist offset
//    		1111:pass: root def chain pointer = son declist chain pointer
//    		end
            visit(root->son1);
            AccumulatSize = TypeSize;
            root->son2->pointer.pvar = root->pointer.pvar;
            root->son2->offset = root->offset;
            visit(root->son2);
            root->offset = root->son2->offset;
            root->pointer.pvar = root->son2->pointer.pvar;
            break;
    	case(DECLIST_type):
            if(root->ProductionType == DECLIST1_pro)
    		{//when declist : dec
//    			1111:set son dec pointerchain = root declist pointerchain
//    			set son dec offset = root declist offset
//    			visit(son dec)
//    			pass: root declist offset = son dec offset
//    			1111:pass: root declist chain pointer = son dec chain pointer
//    			end
                root->son1->pointer.pvar = root->pointer.pvar;
                root->son1->offset = root->offset;
                visit(root->son1);
                root->offset = root->son1->offset;
                root->pointer.pvar = root->son1->pointer.pvar;
                break;
    		}
    		else
    		{//when declist :dec , declist
//    			1111:set son dec pointerchain = root declist pointerchain
//    			set son dec offset = root declist offset
//    			visit(son dec)
//    			passtobrother: son declist offset = son dec offset
//    			1111:passtobrother : son declist pointerchain = son dec pointerchain
//    			visit(son declist)
//    			pass: root declist offset = son declist offset
//    			1111: pass: root declist chain pointer = son declist pointerchain
//    				  cancel//pass: root declist chain pointer = merge two son chain pointer
//    			end
                root->son1->offset = root->offset;
                root->son1->pointer.pvar = root->pointer.pvar;
                visit(root->son1);
                root->son3->offset = root->son1->offset;
                root->son3->pointer.pvar = root->son1->pointer.pvar;
                visit(root->son3);
                root->offset = root->son3->offset;
                root->pointer.pvar = root->son3->pointer.pvar;
                break;
    		}
    		break;

    	case(DEC_type):
            if(root->ProductionType == DEC2_pro)
    		{//when assign operation
//    			if(NestedStruct != 0)
//    			{when in the struct
//    				error:shouldn't' have any assign operation in struct
//    				aftererror
//    			}
//    			else
//    			{when defined in the deflist:dec:vardec = exp 2
//    				set son vardec offset = root dec offset
//    				1111:set son vardec pointerchain = root dec pointerchain
//    				visit(son vardec)
//                  pass: root dec offset = son vardec offset
//    			    pass: root dec chain pointer = son vardec chain pointer
//    				visit(son exp)
//    				//after the son exp visited, we examine the semantics
//    				only vardec = single variable or array elem or single struct elem can assign take place
//    				check type,if not comply error
//    				end
//    			}
//    			end
                if(NestedStructNum!=0)
                {
                    printf("Error type 15 at line %d: Invalid initialization in structure\n",root->line);
                    exit(-3);
                }
                else
                {
                    root->son1->offset = root->offset;
                    root->son1->pointer.pvar = root->pointer.pvar;
                    visit(root->son1);
                    root->offset = root->son1->offset;
                    root->pointer.pvar = root->son1->pointer.pvar;
                    visit(root->son3);
                    if(root->son3->ValueType == array_type)
                    {
                        printf("Error type 18 at line %d:array type is not allowed for expression\n",root->line);
                        exit(-3);
                    }
                    //becasue we can attain the most recent added variable through root->son1 head
                    if(root->pointer.pvar->type != root->son3->TypeOrder)
                    {
                        printf("Error type 5 at line %d:Type mismatched for assignment\n",root->line);
                        exit(-3);
                    }
                    break;
                }
                break;
    		}
    		else
    		{//when dec : vardec
//    			1111: set son vardec pointerchain = root dec pointerchain
//    			set son vardec offset = root dec offset
//    			visit(son vardec)
//    			pass: root dec offset = son vardec offset
//    			1111: pass: root dec chain pointer = son vardec chain pointer
//    			end
                root->son1->pointer.pvar = root->pointer.pvar;
                root->son1->offset = root->offset;
                visit(root->son1);
                root->offset = root->son1->offset;
                root->pointer.pvar = root->son1->pointer.pvar;
                break;
    		}
    		break;

    	case(VARDEC_type)://every time after the vardec done, we update the accumulatesize,dimention,
    				//vector pointer,offset,and pass the offset and chain to father.
            if(root->ProductionType == VARDEC1_pro)
    		{//when vardec : ID
//    			1111: SearchInRootPointerChainTable()//all these return me the pointer
//    				  found: error:conflict line
//    				  aftererror
//    			not found:
//    			create new entry of ArrayAndSingle
//    			set entry type = TypeOrder
//    			set entry size = AccumulatedSize
//    			set entry offset = root vardec offset
//    			set entry innersituationpointer = InnerSituationVectorHead
//    			set entry dimention = dimention
//    			set entry name and entry line
//    			update dimention = 0
//    			update InnerSituationVectorHead = NULL,InnerSituationVectorEnd = NULL
//    			1111: add the local new entry to root vardec pointerchain's' chain//in the front
//    			1111: pass: root chainpointer = added chain's' head
//    			pass: root vardec offset = entry offset
//
//    			update root vardec offset = entry offset + AccumulatedSize
//    			update AccumulatedSize = typesize // if it does not change here, the next var miscalculate
//    			end
                pVARIABLES result = SearchInVariableTable(root->info.ID,root->pointer.pvar);
                if(result)
                {
                    printf("Error type 3 at line %d: Redifined variable \"%s\"\n",root->line,root->info.ID);
                    exit(-3);
                }
                pVARIABLES vlocal = (pVARIABLES)malloc(sizeof(VARIABLES));
                if(!vlocal)
                {
                    puts("malloc failed:CalcAttri.c line 905");
                    exit(-1);
                }
                vlocal->next = NULL;
                vlocal->type = TypeOrder;
                vlocal->size = AccumulatSize;
                vlocal->offset = root->offset;
                vlocal->pointer = InnerHead;
                vlocal->dimention = dimention;
                if(NULL == strcpy(vlocal->name,root->info.ID))
                {
                    puts("strcpy failed:CalcAttri.c line 898");
                    exit(-1);
                }
                vlocal->line = root->line;
                dimention = 0;
                InnerHead = NULL;
                InnerEnd = NULL;
                pVARIABLES temp = root->pointer.pvar;
                root->pointer.pvar = vlocal;
                root->pointer.pvar->next = temp;
                root->offset = vlocal->offset + AccumulatSize;
                AccumulatSize = TypeSize;
                break;
    		}
    		else
    		{//when vardec : vardec [int]
//    			1111:set son vardec pointerchain = root vardec pointerchain
//    			if(InnerSituationVectorHead = NULL)//the first dimention
//    				InnerSituationVectorHead = create new InnerSituationVector;
//    				InnerSituationVectorEnd = InnerSituationVectorHead
//    			else//other dimentions
//    				InnerSituationVectorEnd->next = create new InnerSituationVector
//    				InnerSituationVectorEnd = InnerSituationVectorEnd->next
//    			InnerSituationVectorEnd->maxnum = int here
//    			InnerSituationVectorEnd->next = NULL;
//
//    			set dimention ++ increase by one
//    			set AccumulatedSize = AccumulatedSize * int here
//    			set son vardec offset = root vardec offset
//    			visit(son vardec)
//
//    			1111:pass: root chainpointer = son vardec chainpointer
//    			pass: root vardec offset = son vardec offset
//    			end
                root->son1->pointer.pvar = root->pointer.pvar;
                if(InnerHead == NULL)
                {
                    InnerHead = (pINNERSITUATIONVETOR)malloc(sizeof(INNERSITUATIONVECTOR));
                    if(!InnerHead)
                    {
                        puts("malloc failed: CalcAttri.c line 956");
                        exit(-1);
                    }
                    InnerEnd = InnerHead;
                }
                else
                {
                    InnerEnd->next = (pINNERSITUATIONVETOR)malloc(sizeof(INNERSITUATIONVECTOR));
                    if(!InnerEnd)
                    {
                        puts("malloc failed: CalcAttri.c line 966");
                        exit(-1);
                    }
                    InnerEnd = InnerEnd->next;
                }
                InnerEnd->next = NULL;
                InnerEnd->maxnum = root->info.inum;
                dimention++;
                AccumulatSize = AccumulatSize * root->info.inum;
                root->son1->offset = root->offset;
                visit(root->son1);
                root->pointer.pvar = root->son1->pointer.pvar;
                root->offset = root->son1->offset;
                break;
    		}
    		break;

    	case(EXP_type):
    	switch(root->ProductionType)
    	{
            case(ASSIGNOP_pro):
            {//when:ASSIGNOP_pro exp1 = exp3
//				visit(son exp1)
//				visit(son exp3)
//				if(son exp1->valuetype != SingleVar_type)
//					error:invalid assign for right valuetype and array type
//					aftererror
//				if(son exp3->valuetype == array_type)||(son exp3->TypeOrder!= son exp1->TypeOrder)
//					error:type mismatch
//					aftererror
//				pass:root exp valuetype = rvalue_type
//				pass:root exp TypeOrder = son exp1 TypeOrder
//				end
                visit(root->son1);
                visit(root->son3);
                if(root->son1->ValueType!= SingleVar_type)
                {
                    printf("Error type 6 at line %d: The left-hand side of an assignment must be a variable\n",root->line);
                    exit(-3);
                }
                if(root->son3->ValueType == array_type)
                {
                    printf("Error type 18 at line %d:array type is not allowed for expression\n",root->line);
                    exit(-3);
                }
                if(root->son3->TypeOrder != root->son1->TypeOrder)
                {
                    printf("Error type 5 at line %d: Type mismatched for assignment\n");
                    exit(-3);
                }
                root->ValueType = rvalue_type;
                root->TypeOrder = root->son1->TypeOrder;
                break;
			}
            case(AND_pro):
            case(OR_pro):
            case(EBIG_pro):
            case(ESMALL_pro):
            case(BIG_pro):
            case(SMALL_pro):
            case(EQUAL_pro):
            case(NEQUAL_pro):
            case(PLUS_pro):
            case(MINUS_pro):
            case(STAR_pro):
            case(DIV_pro):
            {//when:AND_pro exp && exp
//				  OR_pro  exp || exp
//				  EBIG_pro exp >= exp
//				  ESMALL_pro exp <= exp
//				  BIG_pro exp > exp
//				  SMALL_pro exp < exp
//				  EQUAL_pro exp == exp
//				  NEQUAL_pro exp != exp
//				  PLUS_pro exp + exp
//				  MINUS_pro exp - exp
//				  STAR_pro exp * exp
//				  DIV_pro  exp / exp
//				  visit(son exp1)
//				  visit(son exp3)
//				  if(son exp1->valuetype == array_type)||(son exp3->valuetype == array_type)
//				  	error:invalid operation for array!
//				  	aftererror
//				  if(son exp1->TypeOrder != son exp3->TypeOrder)
//				  	error:type mismatch!
//				  	aftererror
//				  pass:root exp valuetype = rvalue_type
//				  pass:root exp TypeOrder = son exp TypeOrder
//				  //pass:root exp bind = NULL,pointerchain = NULL
//				  end
                visit(root->son1);
                visit(root->son3);
                if((root->son1->ValueType == array_type)||(root->son3->ValueType == array_type))
                {
                    printf("Error type 18 at line %d:array type is not allowed for expression\n",root->line);
                    exit(-3);
                }
                if(root->son1->TypeOrder != root->son3->TypeOrder)
                {
                    printf("Error type 7 at line %d: Type mismatched for operands\n",root->line);
                    exit(-3);
                }
                root->ValueType = rvalue_type;
                root->TypeOrder = root->son1->TypeOrder;
                break;
			}
            case(NOT_pro):
            case(SINGLEMINUS_pro):
			{//when:NOT_pro !exp
//				SINGLEMINUS_pro -exp
//				visit(son exp)
//				if(son exp->valuetype == array_type)
//					error:array type not allowed
//					aftererror
//				else
//					pass:root exp valuetype = rvalue_type
//				  	pass:root exp TypeOrder = son exp TypeOrder
//				  	//bind:no need for binding
                visit(root->son1);
                if(root->son1->ValueType == array_type)
                {
                    printf("Error type 18 at line %d:array type is not allowed for expression\n",root->line);
                    exit(-3);
                }
                else
                {
                    root->ValueType = rvalue_type;
                    root->TypeOrder = root->son1->TypeOrder;
                }
                break;
			}
			case(LPRPe_pro):
			{//when:LPRPe_pro (exp)
//				because can be situation like (a[1])[2] or (a.b)[1],we have to pass the attribute
//				visit(son exp)
//				pass:root exp pointerchain = son exp pointerchain
//				pass:root exp valuetype = son exp valuetype
//				pass:root exp TypeOrder = son exp TypeOrder
//				//bind:no need for binding
//				end
                visit(root->son2);
                root->pointer.pvar = root->son2->pointer.pvar;
                root->ValueType = root->son2->ValueType;
                root->TypeOrder = root->son2->TypeOrder;
                break;
			}
			case(IDFunctionHasArgs_pro):
            {//when:IDFunctionHasArgs_pro exp:id(Args)
//				search the id in the stack
//				if found:error the id is not a pointer or a function
//						aftererror
//				if notfound:
//                      search the id in the global variable table
//                      iffound:error the id is not a pointer or a function
//                      notfound:
//					    search the id in the functiontable
//						notfound:undefined reference to this function
//						found://when correct,match the args
//						bind:root exp functionpointerchain = founded function symbol table entry
//						update checkargnum = root exp functionpointerchain->ArgNum
//						set son Args pointerchain = root exp functionpointerchain->parameter chain head
//						set checkargnum decrease by one --
//						visit(son Args)
//						pass:root exp valuetype = rvalue_type
//						pass:root exp TypeOrder = root exp functionpointerchain->returntype
//						end
                pVARIABLES result = SearchInStack(root->info.ID,stackHead);
                if(result)
                {
                    printf("Error type 11 at line %d: \"%s\" is not a function or a pointer\n",root->line,root->info.ID);
                    exit(-3);
                }
                result = SearchInVariableTable(root->info.ID,vhead);
                if(result)
                {
                    printf("Error type 11 at line %d: \"%s\" is not a function or a pointer\n",root->line,root->info.ID);
                    exit(-3);
                }
                else
                {
                    pFUNCTION result = SearchInFunctionTable(root->info.ID,fhead);
                    if(!result)
                    {
                        printf("Error type 2 at line %d: Undefined function \"%s\"\n",root->line,root->info.ID);
                        exit(-3);
                    }
                    else
                    {
                        root->pointer.pfun = result;
                        CheckArgNum = result->ParameterNum;
                        root->son1->pointer.pvar = result->ParameterPointer;
                        CheckArgNum--;
                        visit(root->son1);
                        root->ValueType = rvalue_type;
                        root->TypeOrder = result->RetureType;
                    }
                }
                break;
			}
			case(IDFunctionNoArgs_pro):
			{//when:IDFunctionNoArgs_pro
//				search the id in the stack
//				if found:error the id is not a pointer or a function
//						aftererror
//				if notfound:
//                      search the id in the global variable table
//                      if found:error the id is not a pointer or a function
//                              aftererror
//                      notfound:
//					    search the id in the functiontable
//						notfound:undefined reference to this function
//						found:
//						bind:root exp functionpointerchain = founded function symbol table entry
//						if(root exp functionpointerchain->ArgNum != 0)
//							error: parameter mismatch
//							aftererror
//						else
//							pass:root exp valuetype = rvalue_type
//							pass:root exp TypeOrder = root exp functionpointerchain->returntype
//							end
                pVARIABLES result = SearchInStack(root->info.ID,stackHead);
                if(result)
                {
                    printf("Error type 11 at line %d: \"%s\" is not a function or a pointer\n",root->line,root->info.ID);
                    exit(-3);
                }
                result = SearchInVariableTable(root->info.ID,vhead);
                if(result)
                {
                    printf("Error type 11 at line %d: \"%s\" is not a function or a pointer\n",root->line,root->info.ID);
                    exit(-3);
                }
                else
                {
                    pFUNCTION result = SearchInFunctionTable(root->info.ID,fhead);
                    if(!result)
                    {
                        printf("Error type 2 at line %d: Undefined function \"%s\"\n",root->line,root->info.ID);
                        exit(-3);
                    }
                    else
                    {
                        root->pointer.pfun = result;
                        if(result->ParameterNum!=0)
                        {
                            printf("Error type 9 at line %d: Function \"%s\"is not applicable for arguments\n",root->line,root->info.ID);
                            exit(-3);
                        }
                        else
                        {
                            root->ValueType = rvalue_type;
                            root->TypeOrder = result->RetureType;
                        }
                    }
                }
                break;
			}
			case(MATRIX_pro):
			{//when:MATRIX_pro exp: exp1[exp2]
//				visit(son exp1)
//				//get the dimention and valuetype
//				if(son exp1 == rvalue_type)
//					error:invalid [] operation for this exp
//					aftererror
//				else if(son exp1 == SingleVar_type)
//					error:invalid [] operation for this exp
//					aftererror
//				else//only when the array variable
//					visit(son exp2)
//					if(son exp2 TypeOrder != int 0)||(son exp2 valuetype == array_type)
//						error:invalid index for array(not a int or not a number)
//						aftererror
//					else
//						checkdimention--;
//						pass:root exp TypeOrder = son exp1 TypeOrder
//						pass:
//							if(checkdimention ==0)
//								root exp valuetype = SingleVar_type
//							else
//								root exp valuetype = array_type
//						bind:root exp pointerchain = son exp1 pointerchain
//				end
                visit(root->son1);
                if(root->son1->ValueType == rvalue_type)
                {
                    printf("Error type 10 at line %d: [] operation is not applicable for right value\n",root->line);
                    exit(-3);
                }
                else if(root->son1->ValueType == SingleVar_type)
                {
                    printf("Error type 10 at line %d: [] operation is not applicable for single variable\n",root->line);
                    exit(-3);
                }
                else
                {
                    visit(root->son2);
                    if((root->son2->TypeOrder != 0)||(root->son2->ValueType == array_type))
                    {
                        printf("Error type 12 at line %d: the index is not an integer or array type not allowed\n",root->line);
                        exit(-3);
                    }
                    else
                    {
                        CheckDimemtion--;
                        root->TypeOrder = root->son1->TypeOrder;
                        if(CheckDimemtion==0)
                            root->ValueType = SingleVar_type;
                        else
                            root->ValueType = array_type;
                        root->pointer.pvar = root->son1->pointer.pvar;
                    }
                }
                break;
			}
			case(DOT_pro):
			{//when:DOT_pro exp: exp . id
//				visit(son exp)
//				if((son exp->valuetype == SingleVar_type)&&(son exp->TypeOrder >=2))
//					according to the TypeOrder,find the struct in structtable first
//					according to the id, find the id in that specific struct
//						notfound id: error : has no member named "id"
//						aftererror
//					update checkdimention = id dimention
//					pass:root exp TypeOrder = id TypeOrder
//					pass:
//						if(checkdimention == 0)
//							root exp valuetype = SingleVar_type
//						else
//							root exp valuetype = array_type
//					bind:root exp pointerchain = son exp pointerchain//the struct var
//
//				else//the invalid dot operation
//					error:invalid operation for this exp
//					aftererror
//				end
                visit(root->son1);
                if((root->son1->ValueType == SingleVar_type)&&(root->son1->TypeOrder >=2))
                {
                    pSTRUCTTYPE result = SearchInStructTableByTypeOrder(root->son1->TypeOrder,shead);
                    //the result can never be null,cuz the son exp will check it out preceding this step
                    pVARIABLES vresult = SearchInVariableTable(root->info.ID,result->MemberPointer);
                    if(!vresult)
                    {
                        printf("Error type 14 at line %d:Non-existence field \"%s\".\n",root->line,root->info.ID);
                        exit(-3);
                    }
                    CheckDimemtion = vresult->dimention;
                    root->TypeOrder = vresult->type;
                    if(CheckDimemtion==0)
                        root->ValueType = SingleVar_type;
                    else
                        root->ValueType = array_type;
                    root->pointer.pvar = root->son1->pointer.pvar;
                }
                else
                {
                    printf("Error type 13 at line %d: Illegal use of \".\"\n",root->line);
                    exit(-3);
                }
                break;
			}
			case(IDVar_pro):
			{//when:IDVar_pro
//				pResult = SearchInStack(ID);
//				notfound: pResult = SearchInVariableTable(ID,vhead)
//              notfound: error undefined reference
//				aftererror
//				found:
//				bind:root exp pointerchain = pResult;
//				pass:root exp TypeOrder = pResult->TypeOrder
//				update:checkdimention = pResult->dimention;
//				pass:
//					if(checkdimention == 0)
//						root exp valuetype = SingleVar_type
//					else
//						root exp valuetype = array_type
//				end
                pVARIABLES result = SearchInStack(root->info.ID,stackHead);
                if(!result)
                {
                    result = SearchInVariableTable(root->info.ID,vhead);
                }
                if(!result)
                {
                    printf("Error type 1 at line %d:Undefined variable \"%s\".\n",root->line,root->info.ID);
                    exit(-3);
                }
                else
                {
                    root->pointer.pvar = result;
                    root->TypeOrder = result->type;
                    CheckDimemtion = result->dimention;
                    if(CheckDimemtion==0)
                        root->ValueType = SingleVar_type;
                    else
                        root->ValueType = array_type;
                }
                break;
			}
			case(INT_pro):
			{//when:INT_pro
//				pass: root exp TypeOrder = 0;//0 for int
//				pass: root exp LRvalue = rvalue_type;//can not be assigned or else
//				bind:root exp pointerchain = NULL
//				end
                root->TypeOrder = 0;
                root->ValueType = rvalue_type;
                root->pointer.pvar = NULL;
                break;
			}
			case(FLOAT_pro):
			{//when:FLOAT_pro
//				pass: root exp TypeOrder = 1;//0 for int
//				pass: root exp LRvalue = rvalue_type;//can not be assigned or else
//				bind:root exp pointerchain = NULL
//				end
                root->TypeOrder = 1;
                root->ValueType = rvalue_type;
                root->pointer.pvar = NULL;
                break;
			}
    	}
        break;

		case(ARGS_type):
            if(root->ProductionType == ARGS1_pro)
			{//when Args:exp , Args pro1
//				set son Args pointerchain = root Args pointerchain
//				set checkargnum decrease by one --//immediately precede the visit args operation
//				visit(right son Args)
//				visit(left son exp)
//				//check the type
//				if(right son Args->pointerchain->TypeOrder == exp->TypeOrder)&&(exp->valuetype != array_type)
//					//comply
//					pass:root Args pointerchain = son Args pointerchain->next
//					end
//				else
//					//type does not match
//					error:parameter and Args type not matched!(or not a number instead array)
//					aftererror
//					end
                root->son3->pointer.pvar = root->pointer.pvar;
                CheckArgNum--;
                visit(root->son3);
                visit(root->son1);
                if((root->son3->pointer.pvar->type == root->son1->TypeOrder)&&(root->son1->ValueType != array_type))
                {
                    root->pointer.pvar = root->son3->pointer.pvar->next;
                }
                else
                {
                    printf("Error type 9 at line %d: Type mismatched for function parameters\n",root->line);
                    exit(-3);
                }
                break;
			}
			else
			{//when args:exp pro2
//				if(checkargnum != 0)
//					error:parameter num is not right!more or less!
//					aftererror
//				else
//					visit(son exp)
//					if(root arg pointerchain->TypeOrder == exp->TypeOrder)&&(exp->valuetype != array_type)
//						pass:root Args pointerchain = root Args pointerchain->next
//						end
//					else
//						error:type mismatch or array problem
//						aftererror
//						end
                if(CheckArgNum != 0)
                {
                    printf("Error type 9 at line %d: Parameter number mismatched for function\n",root->line);
                    exit(-3);
                }
                else
                {
                    visit(root->son1);
                    if((root->pointer.pvar->type == root->son1->TypeOrder)&&(root->son1->ValueType != array_type))
                    {
                        root->pointer.pvar = root->pointer.pvar->next;
                    }
                    else
                    {
                        printf("Error type 9 ar line %d: Type mismatched for function parameters\n",root->line);
                        exit(-3);
                    }
                }
                break;
			}
			break;
    }//end ot the global switchŝ
    return;
}

pFUNCTION SearchInFunctionTable(char * name,pFUNCTION fhead_local)
{
    while(fhead_local!=NULL)
    {
        if(0 == strcmp(fhead_local->name,name))
            return fhead_local;
        fhead_local = fhead_local->next;
    }
    return fhead_local;//becasue when outof the loop or jump over the loop here the fhead_local is null by nature
}

pSTRUCTTYPE SearchInStructTable(char * name,pSTRUCTTYPE shead_local)
{
    while(shead_local!=NULL)
    {
        if(0 == strcmp(shead_local->name,name))
            return shead_local;
        shead_local = shead_local->next;
    }
    return shead_local;//becasue when outof the loop or jump over the loop here the shead_local is null by nature
}

pVARIABLES SearchInVariableTable(char *name,pVARIABLES vhead_local)
{
    while(vhead_local!= NULL)
    {
        if(0 == strcmp(name,vhead_local->name))
            return vhead_local;
        vhead_local = vhead_local->next;
    }
    return vhead_local;
}

pVARIABLES SearchInStack(char *name , pDEFLISTSTACK stackhead_local)
{
    pVARIABLES result = NULL;
    while(stackhead_local != NULL)
    {
        result = SearchInVariableTable(name,stackhead_local->DeflistChainHead);
        if(result != NULL)
            return result;
        else
            stackhead_local = stackhead_local->next;
    }
    return result;
}

pSTRUCTTYPE SearchInStructTableByTypeOrder(int TypeOrder,pSTRUCTTYPE shead_local)
{
    while(shead_local!=NULL)
    {
        if(shead_local->order == TypeOrder)
            return shead_local;
        else
            shead_local = shead_local->next;
    }
    return shead_local;
}



































