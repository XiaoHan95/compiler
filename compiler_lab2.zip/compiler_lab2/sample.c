int global;

struct A{
	struct B{
		struct C
		{
			int cint;
			float cfloat;
		}c[2][3];
		int bint[1];
		float bfloat[2];
	}b[2][3];
	int aint[2];
	float afloat[2];
}a[2][3];

int main(int b)
{
	main(a);
}
int fun(int a)
{
	1;
}