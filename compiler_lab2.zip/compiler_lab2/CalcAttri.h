#ifndef CALCATTRI_HEAD
#define CALCATTRI_HEAD
typedef enum ValueType{SingleVar_type,array_type,rvalue_type} VALUETYPE;

typedef struct InnerSituationVector{
    int maxnum;
    struct InnerSituationVector * next;
}INNERSITUATIONVECTOR, *pINNERSITUATIONVETOR;

typedef struct variables{
    char name[32];
    int type;//int or float or sturct order
    int offset;
    int size;
    struct variables * next;
    int dimention;
    int line;//in case of error pronouce
    pINNERSITUATIONVETOR pointer;
}VARIABLES,*pVARIABLES;


typedef struct function{
    char name[32];
    int RetureType;
    int begin;
    int end;
    int ParameterNum;
    struct function * next;
    pVARIABLES ParameterPointer;
    int line;//in case of error pronounce
} FUNCTION,*pFUNCTION;

typedef struct SructType{
    char name[32];
    int order;
    int size;
    int funscope;
    int compstscope;
    int compstnumscope;
    struct SructType * next;
    pVARIABLES MemberPointer;
    int line;//in case of error pronounce
} STRUCTTYPE, *pSTRUCTTYPE;

typedef union SymbolPointer{
    pVARIABLES pvar;
    pSTRUCTTYPE pstr;
    pFUNCTION pfun;
}SYMBOLPOINTER,*pSYMBOLPOINTER;

typedef struct DeflistStack{
    pVARIABLES DeflistChainHead;
    struct DeflistStack * next;
}DEFLISTSTACK,*pDEFLISTSTACK;

extern int TypeSize;//the size for struct or something else
extern int TypeOrder;//0 for int ,1 for float , other positives for struct order
extern int AccumulatSize;
extern pINNERSITUATIONVETOR InnerHead,InnerEnd;
extern int dimention;
extern int ArgNum;
extern int NestedStructNum;//one struct has one number.
extern int FunNum;
extern int CompstLevel;
extern int CompstNum;
extern int InFun;
extern pVARIABLES vhead;
extern pSTRUCTTYPE shead;
extern pFUNCTION fhead;

extern int StructType;//0 for type int, 1 for type float, so the struct type rank begin with 2
extern int CheckDimemtion;
extern int CheckArgNum;
extern pDEFLISTSTACK stackHead;

pFUNCTION SearchInFunctionTable(char * name,pFUNCTION fhead_local);
pSTRUCTTYPE SearchInStructTable(char * name,pSTRUCTTYPE shead_local);
pVARIABLES SearchInVariableTable(char *name,pVARIABLES vhead_local);
pVARIABLES SearchInStack(char *name , pDEFLISTSTACK stackhead_local);
pSTRUCTTYPE SearchInStructTableByTypeOrder(int TypeOrder,pSTRUCTTYPE shead_local);
#endif // CALCATTRI_HEAD

