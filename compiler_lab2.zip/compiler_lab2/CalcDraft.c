 	global line//error information
 	global typesize 
 	global TypeOrder = 2;
 	global AccumulatedSize//change at the same time when typesize change, and set their value the same
 	global InnerSituationVectorHead = NULL, InnerSituationVectorEnd = NULL, dimention = 0,
 	global ArgNum = 0;
 	global NestedStruct = 0;
 	7777:global FunNum = 0; compstlevel = -1;//when in compst ++, outof compst --
 		 global InFun = 0;//if in the function, then infun is 1
 	1111:global vhead = NULL;//this store the global variables chain head
 	6666:global checkdimention;//used to check the array validability
 	6666:some added elements in tree node
 	6666:global checkargnum;//used to check the arg num consistency
 	enum

 	//scope: do not need them,cuz the deflist and extdeflist stack will solve this
    switch(root->nodetype)
   	{
   		case(program):
   			1111:set son extdeflist pointerchain = NULL
   			set root program offset = 0;
   			set son extdeflist offset = 0;
   			visit(son extdeflist)
   			pass root program offset = son extdeflist offset
   			end
   		case(extdeflist):
   			{when extdeflist : empty
   				end
   			}
   			{when extdeflist : extdef extdeflist
   				1111:set son extdef pointerchain = root extdeflist pointerchain
   				set son extdef offset = root extdeflist offset
   				visit(son extdef)
   				passtobrother: set son extdeflist offset = son extdef offset
   				1111:passtobrother : set son extdeflist pointerchain = son extdef pointerchain
   				visit(son extdeflist)
   				pass: root extdeflist offset = son extdeflist offset
   				1111: pass root extdeflist pointerchain = son extdeflist pointerchain
   				end
   			}
   		case(extdef):
   			{when extdef : specifier extdeclist;
   			 	visit(son specifier)
   			 	1111:set son extdeclist pointerchain = root extdef pointerchain
   			 	set son extdeclist offset = root extdef offset
   			 	visit(son extdeclist)
   			 	pass: root extdef offset = son extdeclist offset
   			 	1111:pass: root extdef pointer chain = son extdeclist pointer chain//this is global one
          		1111:cancel//add entry to global variable array list
          		1111:vhead = root extdef pointerchain//the global var head information
   			 	end
   			}
   			{when extdef : specifier ;
   				0000:
   				visit(son specifier);
   				end//do not change the offset by any means
   			}
   			{when extdef : specifier fundec compst
   				1111:because the transport between brother,the root extdef has the global variable
   					 chain head information
   				ArgNum = 0;
   				7777:InFun = 1;
   				visit(son specifier)
   				1111:set son fundec pointerchain = NULL
   				visit(son fundec)
   				1111:passtobrother: son compst pointerchain = son fundec pointerchains
   				passtobrother: son compst offset = son fundec offset
   				visit(son compst)
   				1111://because we have not change the pointerchain of extdef,it is save for global variable
   				7777:InFun = 0;//outof the function
   				end
   			}	
   		case(extdeclist):
   			{when extdeclist: vardec,extdeclist
   				1111:set son vardec pointerchain = root extdeclist pointerchain
   				set son vardec offset = root extdeclist offset
   				visit(son vardec)
   				passtobrother: son extdeclist offset = son vardec offset
   				1111:passtobrother : son extdeclist pointerchain = son vardec pointerchain
   				visit(son extdeclist)
   				pass: set root extdeclist offset = son extdeclist offset; 
   				1111:pass root extdeclist pointerchain = son extdeclist pointerchain
   					cancel//pass: merge the son vardec chain and son extdeclist chain
   				end
   			}
   			{when extdeclist:vardec
   				1111:set son vardec pointerchain = root extdeclist pointerchain
   				set son vardec offset = root extdeclist offset
   				visit(son vardec)
   				pass: set root extdeclist offset = son extdeclist offset; 
   				1111:pass: set root extdeclist pointerchain = son vardec pointerchain
   				end   				
   			}
/******************************************************************************************************/
   		case(fundec):
   		0000:
   		{when fundec:id (varlist) 1
   			3333:lookupinfunctiontable(ID)
   				found:rename overlap problem
   				aftererror
   			notfound:
   			create local function entry
   			7777: FunNum++;
   			set functin entry return type = TypeOrder
   			set function name = strcpy ID
   			set function line 
   			add local function to global
   			set son varlist offset = 0
   			1111:set son varlist pointerchain = root fundec pointerchain
   			visit(son varlist)
   			pass: root fundec offset = son varlist offset
   			set function memberpointer = son varlist
   			set function ArgNum = ArgNum
   			1111:pass: root fundec pointerchain = son varlist pointerchain
   			//we do not need to clear the argnum,because every time we enter the function we clear it 
   			//automatically
   			end
   		}
   		{when fundec:id() 2
   			3333:lookupinfunctiontable(ID)
   			found:rename overlap problem
   			aftererror
   			notfound:
   			create local function entry
   			7777:FunNum++
   			set functin entry return type = TypeOrder
   			set function name = strcpy ID
   			set function line 
   			add local function to global
   			set root function memberpointer  = NULL
   			set root function argnum = 0;   
   			pass: root function offset = 0;
   			1111:pass:root fundec pointerchain = NULL;		
   		}

   		case(varlist):
   			{when varlist: paramdec , varlist
   				set son paramdec offset = root varlist offset
   				1111:set son paramdec pointerchain = root varlist pointerchain
   				visit(son paramdec)
   				1111:passtobrother: son varlist pointerchain = son paramdec pointerchain
   				passtobrother: son varlist offset = son paramdec offset
   				visit(son varlist)
   				pass: root varlist offset = son varlist offset
   				//the paramdec son has only one entry,so it is easier to deal with
   				//and by adding the varlist chain to paramdec chain, we form the parameter sequence
   				1111:pass: root varlist pointerchain = son varlist pointerchain
   					 cancel//pass: root varlist chainpointer = merge son paramdec chainpointer and son varlist chainpointer
   				end
			}
			{when varlist : paramdec
				1111:set son paramdec pointerchain = root varlist pointerchain
				set son paramdec offset = root varlist offset
				visit(son paramdec)
				pass: root varlist offset = son paramdec offset
				1111:pass: root varlist chainpointer = son paramdec chainpointer
				end
			}
		case(paramdec):
			set ArgNum increase by one++
			visit(son specifier)
			1111:set son vardec pointerchain = roo paramdec pointerchain
			set son vardec offset = root paramdec offset
			visit(son vardec)
			pass: root paramdec offset = son vardec offset
			1111:pass: root paramdec chainpointer = son vardec chainpointer
			end
/******************************************************************************************************/		
   		case(compst):
   			1111:set son deflist pointerchain = root compst pointerchain
   			7777:compstlevel++;//so the defined struct has scope and invisualbility
   							   //so the struct defined in the parameter list is not in the compst
   							   //but even their compstlevel scope different from each other, 
   							   //one for -1 one for 0.they are global in the function level
   				compstnum++;	
   			set son deflist offset = root compst offset;
   			visit(son deflist)
   			4444:push deflist pointerchain into stackofvariables
   			//even the function parameter will be pushed in because of the transportation made 
   			//the compst inherit the fundec parameter chain information
   			pass: root compst offset = son deflist offset
  			//we do not need to set son stmtlist offset
   			visit(son stmtlist)
   			7777:compstlevel--;
   			4444:pop deflist pointerchain outof stack
   			end
   			//visit other stmtlist, because the compst may be nested in them and we need to get them
   		case(stmtlist):
   			{when empty
   				end
   			}
   			{when stmtlist : stmt stmtlist
   				visit(son stmt)
   				visit(son stmtlist)
   				end
   				//both do not need set offset
   			}
   		case(stmt):
   			{when stmt:compst pro2
   				1111:set son compst pointerchain = NULL;//free from outer name worries
   				set son compst offset = 0;
   				visit(son compst)
   				end
   			}
   			{when stmt:exp; pro1
   				visit(son exp)
   				if(son exp ->valuetype == array_type)
   					error:array not allowed!
   					aftererror   					
   				end
   			}

   			{when stmt:return exp; pro3
   				//because the recent function entry is in the fhead and is the first 
   				//i can have easy access to it using fhead
   				visit(son exp)
   				if(son exp->valuetype == array_type)
   					error:array not allowed!
   					aftererror
   				if(son exp->TypeOrder != fhead->returntype)
   					error:return type mismatch!
   					aftererror
   				end
   			}

   			{when stmt:if(exp) stmt pro4
   				visit(son exp)
   				if(son exp -> valuetype == array_type)
   					error:array not allowed
   					aftererror
   				if(son exp ->TypeOrder != 0)
   					error:boolean not allowed for non int type!
   					aftererror
   				visit(son stmt)
   				end
   			}

   			{when stmt:if(exp) stmt else stmt pro5
   				visit(son exp)
   				if(son exp -> valuetype == array_type)
   					error:array not allowed
   					aftererror
   				if(son exp ->TypeOrder != 0)
   					error:boolean not allowed for non int type!
   					aftererror
   				visit(son stmt)
   				visit(son stmt)
   			}

   			{when stmt:while(exp) stmt pro6
   				visit(son exp)
   				if(son exp -> valuetype == array_type)
   					error:array not allowed
   					aftererror
   				if(son exp ->TypeOrder != 0)
   					error:boolean not allowed for non int type!
   					aftererror
   				visit(son stmt)
   				end
   			}

    	case(specifier):
    		if(int or float)
    			update typesize = AccumulatedSize = 4;
    			update TypeOrder
    		else
    			visit(son structspecifier)
    			end
    	case(structspecifier):
    		{when structspecifier: struct  tag
    			7777:pResult = lookupinsturcttable(tag)
    			notfound: error undefined structure
          found:
    			if(InFun == 0)
    				//when outside
    				if(pResult->funnum scope != 0)
    					error:invisible struct!
    					aftererror
    				else
    					update typesize  = lookupinsturcttable(tag).size
    					update TypeOrder = lookupinsturcttable(tag).TypeOrder
    					update AccumulateSize = typesize
    			if(InFun != 0)
    				//when in function
    				if( (pResult->scope FunNum != FunNum)&&(pResult->scope FunNum!=0) ) ||
    				  (pResult->scope compstlevel>compstlevel) ||
    					((pResult->scope compstlevel == compstlevel)&&(pResult->scope compstnum != compstnum))
    					error:invisible struct!
    					aftererror
    				else
    					update typesize  = lookupinsturcttable(tag).size
    					update TypeOrder = lookupinsturcttable(tag).TypeOrder
    					update AccumulateSize = typesize
    			end
    		}
    		{when structspecifier:struct OptTag {deflist}
    			2222:lookupinsturcttable(OptTag) //check the rename
    				found:rename problem//line known
    				aftererror
    			notfound:
    			create local new entry
    			NestedStruct++;
    			7777:if(InFun == 1)
    				set local scope = FunNum
    				set local scope = compstlevel
    				set local scope = compstnum
    			7777:else
    				set local scope = 0;
    				set local scope = -1;//when scope = 0 ,the second parameter we do not care
    				set local scope = -1//when scope =0 ,the third parameter we do not care
    			set local name
    			set local TypeOrder
    			update TypeOrder by one++
    			1111:add local new entry to global//be aware the following information was
    											  //added via local entry pointer.
    			1111:set son deflist pointerchain = NULL
    			set son deflist offset = 0
    			visit(son deflist)
    			set local size = son deflist offset
    			set local memberpointer = son deflist pointer chain
    			update typesize = local size
    			update TypeOrder = local TypeOrder
    			update AccumulatedSize = typesize
    			NestedStruct--;
    			end
    		}

    	case(deflist):
    		{when deflist: def and deflist
    			set son def offset = root deflist offset
    			1111:set son def pointerchain = root deflist pointerchain
    			visit(son def)
    			passtobrother: son deflist offset = son def offset
    			1111:passtobrother: son deflist pointerchain = son def pointerchain
    			visit(son deflist)
    			pass: root deflist offset = son deflist offset
    			1111: pass: root deflist chain pointer = son deflist pointerchain
    			1111:cancel//pass: root deflist chain pointer = merge two son chain pointer
    			end
    		}
    		{when deflist: empty
    			1111: end//do nothing,cuz the pointer chain and offset has just received from brother
    			1111: cancel //pass: root deflist chain pointer = NULL;
    			//the offset does not need managing
    			//do nothing
    			end
    		}
    	case(def):
    		visit(son specifier) , get typesize and TypeOrder
    		set AccumulatedSize = typesize//change at the same time
    		1111:set son declist pointerchain = root def pointerchain
    		set son declist offset = root def offset
    		visit(son declist)
    		pass: root def offset = son declist offset
    		1111:pass: root def chain pointer = son declist chain pointer
    		end
    	case(declist):
    		{when declist : dec 
    			1111:set son dec pointerchain = root declist pointerchain
    			set son dec offset = root declist offset
    			visit(son dec)
    			pass: root declist offset = son dec offset
    			1111:pass: root declist chain pointer = son dec chain pointer
    			end
    		}
    		{when declist :dec , declist
    			1111:set son dec pointerchain = root declist pointerchain
    			set son dec offset = root declist offset
    			visit(son dec)
    			passtobrother: son declist offset = son dec offset
    			1111:passtobrother : son declist pointerchain = son dec pointerchain
    			visit(son declist)
    			pass: root declist offset = son declist offset
    			1111: pass: root declist chain pointer = son declist pointerchain
    				  cancel//pass: root declist chain pointer = merge two son chain pointer
    			end
    		}
    	case(dec):
    		{when assign operation
    			if(NestedStruct != 0)
    			{when in the struct 
    				error:shouldn't' have any assign operation in struct
    				aftererror
    			}
    			else
    			{when defined in the deflist:dec:vardec = exp 2
    				set son vardec offset = root dec offset
    				1111:set son vardec pointerchain = root dec pointerchain
    				visit(son vardec)
            pass: root dec offset = son vardec offset
            pass: root dec chain pointer = son vardec chain pointer
    				visit(son exp)
    				//after the son exp visited, we examine the semantics
    				only vardec = single variable or array elem or single struct elem can assign take place
    				check type,if not comply error
    				end
    			}
    			end
    		}
    		{when dec : vardec
    			1111: set son vardec pointerchain = root dec pointerchain
    			set son vardec offset = root dec offset
    			visit(son vardec)
    			pass: root dec offset = son vardec offset
    			1111: pass: root dec chain pointer = son vardec chain pointer
    			end
    		}
    	case(vardec)://every time after the vardec done, we update the accumulatesize,dimention,
    				//vector pointer,offset,and pass the offset and chain to father.
    		{when vardec : ID
    			1111: SearchInRootPointerChainTable()//all these return me the pointer
    				  found: error:conflict line
    				  aftererror
    			not found:
    			create new entry of ArrayAndSingle	
    			set entry type = TypeOrder
    			set entry size = AccumulatedSize
    			set entry offset = root vardec offset
    			set entry innersituationpointer = InnerSituationVectorHead
    			set entry dimention = dimention
    			set entry name and entry line
    			update dimention = 0
    			update InnerSituationVectorHead = NULL,InnerSituationVectorEnd = NULL
    			1111: add the local new entry to root vardec pointerchain's' chain//in the front
    			1111: pass: root chainpointer = added chain's' head
    			pass: root vardec offset = entry offset

    			update root vardec offset = entry offset + AccumulatedSize
    			update AccumulatedSize = typesize // if it does not change here, the next var miscalculate    			
    			end
    		}
    		{when vardec : ID [int]
    			1111:set son vardec pointerchain = root vardec pointerchain
    			if(InnerSituationVectorHead = NULL)//the first dimention
    				InnerSituationVectorHead = create new InnerSituationVector;
    				InnerSituationVectorEnd = InnerSituationVectorHead
    			else//other dimentions
    				InnerSituationVectorEnd->next = create new InnerSituationVector
    				InnerSituationVectorEnd = InnerSituationVectorEnd->next
    			InnerSituationVectorEnd->maxnum = int here
    			InnerSituationVectorEnd->next = NULL;

    			set dimention ++ increase by one
    			set AccumulatedSize = AccumulatedSize * int here
    			set son vardec offset = root vardec offset
    			visit(son vardec)

    			1111:pass: root chainpointer = son vardec chainpointer 
    			pass: root vardec offset = son vardec offset
    			end
    		}
    	case(exp):
			{when:ASSIGNOP_pro exp1 = exp3
				visit(son exp1)
				visit(son exp3)
				if(son exp1->valuetype != SingleVar_type)
					error:invalid assign for right valuetype and array type
					aftererror
				if(son exp3->valuetype == array_type)||(son exp3->TypeOrder!= son exp1->TypeOrder)
					error:type mismatch
					aftererror
				pass:root exp valuetype = rvalue_type
				pass:root exp TypeOrder = son exp1 TypeOrder				
				end
			}
			{when:AND_pro exp && exp
				  OR_pro  exp || exp
				  EBIG_pro exp >= exp
				  ESMALL_pro exp <= exp
				  BIG_pro exp > exp
				  SMALL_pro exp < exp
				  EQUAL_pro exp == exp
				  NEQUAL_pro exp != exp
				  PLUS_pro exp + exp
				  MINUS_pro exp - exp
				  STAR_pro exp * exp
				  DIV_pro  exp / exp
				  visit(son exp1)
				  visit(son exp3)
				  if(son exp1->valuetype == array_type)||(son exp3->valuetype == array_type)
				  	error:invalid operation for array!
				  	aftererror
				  if(son exp1->TypeOrder != son exp3->TypeOrder)
				  	error:type mismatch!
				  	aftererror
				  pass:root exp valuetype = rvalue_type
				  pass:root exp TypeOrder = son exp TypeOrder
				  //pass:root exp bind = NULL,pointerchain = NULL
				  end
			}
			{when:NOT_pro !exp
				SINGLEMINUS_pro -exp
				visit(son exp)
				if(son exp->valuetype == array_type)
					error:array type not allowed
					aftererror
				else
					pass:root exp valuetype = rvalue_type
				  	pass:root exp TypeOrder = son exp TypeOrder
				  	//bind:no need for binding
			}
			{when:LPRPe_pro (exp)
				because can be situation like (a[1])[2] or (a.b)[1],we have to pass the attribute 
				visit(son exp)
				pass:root exp pointerchain = son exp pointerchain
				pass:root exp valuetype = son exp valuetype
				pass:root exp TypeOrder = son exp TypeOrder
				//bind:no need for binding
				end
			}

			{when:IDFunctionHasArgs_pro exp:id(Args)
				search the id in the stack
				if found:error the id is not a pointer or a function
						aftererror
        search the id in the global variable table
        if found:error the id is not a pointer or a function
          aftererror
				if notfound:
					search the id in the functiontable
						notfound:undefined reference to this function
						found://when correct,match the args
						bind:root exp functionpointerchain = founded function symbol table entry
						update checkargnum = root exp functionpointerchain->ArgNum
						set son Args pointerchain = root exp functionpointerchain->parameter chain head
						set checkargnum decrease by one -- 
						visit(son Args)
						pass:root exp valuetype = rvalue_type
						pass:root exp TypeOrder = root exp functionpointerchain->returntype
						end
			}
			{when:IDFunctionNoArgs_pro
				search the id in the stack
				if found:error the id is not a pointer or a function
						aftererror
        search the id in the global variable table
        if found:error the id is not a pointer or a function
          aftererror
				if notfound:
					search the id in the functiontable
						notfound:undefined reference to this function
						found:
						bind:root exp functionpointerchain = founded function symbol table entry
						if(root exp functionpointerchain->ArgNum != 0)
							error: parameter mismatch
							aftererror
						else
							pass:root exp valuetype = rvalue_type
							pass:root exp TypeOrder = root exp functionpointerchain->returntype
							end
			}
			{when:MATRIX_pro exp: exp1[exp2]
				visit(son exp1)
				//get the dimention and valuetype
				if(son exp1 == rvalue_type)
					error:invalid [] operation for this exp
					aftererror
				else if(son exp1 == SingleVar_type)
					error:invalid [] operation for this exp
					aftererror
				else//only when the array variable
					visit(son exp2)
					if(son exp2 TypeOrder != int 0)||(son exp2 valuetype == array_type)
						error:invalid index for array(not a int or not a number)
						aftererror
					else
						checkdimention--;
						pass:root exp TypeOrder = son exp1 TypeOrder
						pass: 
							if(dimention ==0)
								root exp valuetype = SingleVar_type
							else
								root exp valuetype = array_type
						bind:root exp pointerchain = son exp1 pointerchain
				end
			}
			{when:DOT_pro exp: exp . id
				visit(son exp)
				if((son exp->valuetype == SingleVar_type)&&(son exp->TypeOrder >=2))
					according to the TypeOrder,find the struct in structtable first
					according to the id, find the id in that specific struct
						notfound id: error : has no member named "id"
						aftererror
					update checkdimention = id dimention
					pass:root exp TypeOrder = id TypeOrder
					pass:
						if(checkdimention == 0)
							root exp valuetype = SingleVar_type
						else
							root exp valuetype = array_type
					bind:root exp pointerchain = son exp pointerchain//the struct var

				else//the invalid dot operation
					error:invalid operation for this exp
					aftererror
				end
			}
			{when:IDVar_pro
				pResult = SearchInStack(ID);
				notfound:pResult = Search in the global variable table
        notfound:undefined reference of the id
				aftererror
				found:
				bind:root exp pointerchain = pResult;
				pass:root exp TypeOrder = pResult->TypeOrder
				update:checkdimention = pResult->dimention;
				pass:
					if(checkdimention == 0)
						root exp valuetype = SingleVar_type
					else
						root exp valuetype = array_type
				end
			}
			{when:INT_pro
				pass: root exp TypeOrder = 0;//0 for int
				pass: root exp LRvalue = rvalue_type;//can not be assigned or else
				bind:root exp pointerchain = NULL
				end 
			}
			{when:FLOAT_pro
				pass: root exp TypeOrder = 1;//0 for int
				pass: root exp LRvalue = rvalue_type;//can not be assigned or else
				bind:root exp pointerchain = NULL
				end 
			}
		case(Args):
			{when Args:exp , Args pro1
				set son Args pointerchain = root Args pointerchain
				set checkargnum decrease by one --//immediately precede the visit args operation
				visit(right son Args)
				visit(left son exp)
				//check the type
				if(right son Args->pointerchain->TypeOrder == exp->TypeOrder)&&(exp->valuetype != array_type)
					//comply
					pass:root Args pointerchain = son Args pointerchain->next
					end
				else
					//type does not match
					error:parameter and Args type not matched!(or not a number instead array)
					aftererror
					end
			}
			{when args:exp pro2
				if(checkargnum != 0)
					error:parameter num is not right!more or less!
					aftererror
				else
					visit(son exp)
					if(root arg pointerchain->TypeOrder == exp->TypeOrder)&&(exp->valuetype != array_type)
						pass:root Args pointerchain = root Args pointerchain->next
						end
					else
						error:type mismatch or array problem
						aftererror
						end
			}

    }
    return ;


1111:i change the way how deflist form the chain. It no longer merge the chain at the root.
	 instead, it transport the chain to the brother. So in this way i can guarantee the names
	 in deflist will not overlap

2222:struct name problem
3333:function name problem//rename functions, and name problem when called
4444:stack tech deal with name checking
5555:deflist var name problem
6666:expression attri calculation problem

7777:support struct defined in the compst and invisualbility



0000: incomplete dec:vardec assignop exp//imcomplete exp check and variable binding
	  incomplete exp,args

8888:about parameter array problem:when define a function, the format parameter will
	 have no tolerance for array.But the actual parameter can be array, but should 
	 be single array elem,which can be achieved through valuetype attribute in treenode.