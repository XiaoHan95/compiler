#include "node.h"
#include "compiler.tab.h"
#include "stdio.h"
#include "stdlib.h"
pNODE newtree(pNODE son1,pNODE son2,pNODE son3,int nodetype,int productiontype,char *ID,int line){
	pNODE a = (pNODE)malloc(sizeof(NODE));
	if(!a)
	{
		puts("unexpected error: no space for new node of the tree. treefuncs.c:7");
		exit(-1);
	}
	a->son1 = son1;
	a->son2 = son2;
	a->son3 = son3;
	a->nodetype = nodetype;
	a->ProductionType = productiontype;
	a->line = line;
	//we need to copy the values from ID into the union of the node,so 32 times of assign value needed
	int i = 0;
	if(ID == NULL)
		while(i <32)
		{
			a->info.ID[i] = '\0';
			i++;
		}
	else//when we need to assign a value to the node except from the nodetype
		while(i < 32)
		{
			a->info.ID[i] = ID[i];
			i++;
		}
	return a;
}

void display(pNODE root,int ident){
	if(root == NULL)
		return;
	switch(root->nodetype)
	{
		case(ERROR_type):
		{
			printf("%*cerror:ERROR_pro\n",ident,' ');
			break;
		}
		case(START_type):
		{
			//printf("%*cstart:START_type\n",ident,' ');
			//puts("son1");
			display(root->son1,ident);
			//puts("son2");
			display(root->son2,ident);
			//puts("son3");
			display(root->son3,ident);
			break;
		}

		case(EXP_type):
		{
			switch(root->ProductionType)
			{
			case(INT_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				printf("%*cINT:%d\n",ident+2,' ',root->info.inum);
				break;
			case(FLOAT_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				printf("%*cFLOAT:%f\n",ident+2,' ',root->info.fnum);
				break;
			case (PLUS_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cPLUS\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			case(MINUS_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cMINUS\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			case(STAR_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cSTAR\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			case(DIV_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cDIV\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			case(EBIG_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cRELOP\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			case(ESMALL_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cRELOP\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			case(BIG_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cRELOP\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			case(SMALL_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cRELOP\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			case(EQUAL_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cRELOP\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			case(NEQUAL_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cRELOP\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			case(OR_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cOR\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			case(AND_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cAND\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			case(ASSIGNOP_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cASSIGNOP\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			case(LPRPe_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				printf("%*cLP\n",ident+2,' ');
				display(root->son2,ident+2);
				printf("%*cRP\n",ident+2,' ');
				break;
			case(SINGLEMINUS_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				printf("%*cMINUS\n",ident+2,' ');
				display(root->son2,ident+2);
				break;
			case(NOT_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				printf("%*cNOT\n",ident+2,' ');
				display(root->son2,ident+2);
				break;
			case(IDVar_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				printf("%*cID:%s\n",ident+2,' ',root->info.ID);
				break;
			case(IDFunctionNoArgs_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				printf("%*c%s\n",ident+2,' ',root->info.ID);
				printf("%*cLP\n",ident+2,' ');
				printf("%*cRP\n",ident+2,' ');
				break;
			case(DOT_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cDOT\n",ident+2,' ');
				printf("%*c%s\n",ident+2,' ',root->info.ID);
				break;
			case(MATRIX_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cLB\n",ident+2,' ');
				display(root->son2,ident+2);
				printf("%*cRB\n",ident+2,' ');
				break;
			case(IDFunctionHasArgs_pro):
				printf("%*cexp:   (%d)\n",ident,' ',root->line);
				printf("%*c%s\n",ident+2,' ',root->info.ID);
				printf("%*cLP\n",ident+2,' ');
				display(root->son1,ident+2);
				printf("%*cRP\n",ident+2,' ');
				break;
			default:
				puts("unexpected error: unknown pro in EXP_type node. treefuncs.c:173");
			}//end of EXP_type switch
			break;
		}//end of EXP_type case
		case(ARGS_type):
		{
			switch(root->ProductionType)
			{
			case(ARGS1_pro):
				printf("%*cArgs:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cCOMMA\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			case(ARGS2_pro):
				printf("%*cArgs:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				break;
			default:
				puts("unexpected error: unknown pro in ARGS_type node. treefuncs.c:192");
			}
			break;
		}

		case(DEC_type):
		{
			switch(root->ProductionType)
			{
			case(DEC1_pro):
				printf("%*cDec:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				break;
			case(DEC2_pro):
				printf("%*cDec:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cASSIGNOP\n",ident+2,' ');
				display(root->son3,ident+2);
				break;
			default:
				puts("unexpected error: unknown pro in DEC_type node. treefuncs.c:219");
			}
			break;
		}
		case(VARDEC_type):
		{
			switch(root->ProductionType)
			{
			case(VARDEC1_pro):
				printf("%*cVarDec:   (%d)\n",ident,' ',root->line);
				printf("%*cID:%s\n", ident+2,' ',root->info.ID);
				break;
			case(VARDEC2_pro):
				printf("%*cVarDec:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cLB\n",ident+2,' ');
				printf("%*cINT:%d\n",ident+2,' ',root->info.inum);
				printf("%*cRB\n",ident+2,' ');
				break;
			default:
				puts("unexpected error: unknown pro in VARDEC_type node. treefuncs.c:241");
			}
			break;
		}
		case(DECLIST_type):
		{
			if(root->ProductionType == DECLIST1_pro)
			{
				printf("%*cDecList:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
			}
			else if(root->ProductionType == DECLIST2_pro)
			{
				printf("%*cDecList:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cCOMMA\n",ident+2,' ');
				display(root->son3,ident+2);
			}
			else
				puts("unexpected error: unknown pro in DECLIST_type node. treefuncs.c:267");
			break;
		}
		case(SPECIFIER_type):
		{
			switch(root->ProductionType)
			{
			case(TYPEINT_pro):
				printf("%*cSpecifier:   (%d)\n",ident,' ',root->line);
				printf("%*cTYPE:  int\n",ident+2,' ');
				break;
			case(TYPEFLOAT_pro):
				printf("%*cSpecifier:   (%d)\n",ident,' ',root->line);
				printf("%*cTYPE:  float\n",ident+2,' ');
				break;
			case(SPECIFIER3_pro):
				printf("%*cSpecifier:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				break;
			default:
				puts("unexpected error: unknown pro in SPECIFIER_type node. treefuncs.c:287");
			}
			break;
		}
		case(STRUCTSPECIFIER_type):
		{
			if(root->ProductionType == STRUCTSPECIFIER1_pro)
			{
				printf("%*cStructSpecifier:   (%d)\n",ident,' ',root->line);
				printf("%*cstruct\n",ident+2,' ');
				display(root->son1,ident+2);
				printf("%*cLC\n",ident+2,' ');
				display(root->son2,ident+2);
				printf("%*cRC\n",ident+2,' ');
			}
			else if(root->ProductionType == STRUCTSPECIFIER2_pro)
			{
				printf("%*cStructSpecifier:   (%d)\n",ident,' ',root->line);
				printf("%*cstruct\n",ident+2,' ');
				display(root->son2,ident+2);
			}
			else
				puts("unexpected error: unknown pro in STRUCTSPECIFIER_type node. treefuncs.c:309");
			break;
		}
		case(OPTTAG_type):
		{
			if(root->ProductionType == OPTTAG_pro)
			{
				printf("%*cOptTag:   (%d)\n",ident,' ',root->line);
				printf("%*cID: %s\n",ident+2,' ',root->info.ID);
			}
			else if(root->ProductionType == OPTTAG_empty)
			{
				//printf("%*cOptTag:OPTTAG_empty   (%d)\n",ident,' ',root->line);
				//printf("%*c---------------empty rule\n",ident+2,' ');
			}
			break;
		}
		case(TAG_type):
		{
			printf("%*cTag:   (%d)\n",ident,' ',root->line);
			printf("%*cID: %s\n",ident+2,' ',root->info.ID);
			break;
		}
		case(DEF_type):
		{
			printf("%*cDef:   (%d)\n",ident,' ',root->line);
			display(root->son1,ident+2);
			display(root->son2,ident+2);
			printf("%*cSEMI\n",ident+2,' ');
			break;
		}
		case(DEFLIST_type):
		{
			if(root->ProductionType == DEFLIST_pro)
			{
				printf("%*cDefList:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				display(root->son2,ident+2);
			}
			else if(root->ProductionType == DEFLIST_empty)
			{
				//printf("%*cDefList:DEFLIST_empty   (%d)\n",ident,' ',root->line);
				//printf("%*c---------------empty rule\n",ident+2,' ');
			}
			break;
		}
		case(COMPST_type):
		{
			printf("%*cCompSt:   (%d)\n",ident,' ',root->line);
			printf("%*cLC\n",ident+2,' ');
			display(root->son1,ident+2);
			display(root->son2,ident+2);
			printf("%*cRC\n",ident+2,' ');
			break;
		}
		case(STMTLIST_type):
		{
			if(root->ProductionType == STMTLIST_pro)
			{
				printf("%*cStmtList:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				display(root->son2,ident+2);
			}
			else if(root->ProductionType == STMTLIST_empty)
			{
				//printf("%*cStmtList:STMTLIST_empty   (%d)\n",ident,' ',root->line);
				//printf("%*c---------------empty rule\n",ident+2,' ');
			}
			break;
		}
		case(STMT_type):
		{
			switch(root->ProductionType)
			{
				case(STMT1_pro):
					printf("%*cStmt:   (%d)\n",ident,' ',root->line);
					display(root->son1,ident+2);
					printf("%*cSEMI\n",ident+2,' ');
					break;
				case(STMT2_pro):
					printf("%*cStmt:   (%d)\n",ident,' ',root->line);
					display(root->son1,ident+2);
					break;
				case(STMT3_pro):
					printf("%*cStmt:   (%d)\n",ident,' ',root->line);
					printf("%*creturn\n",ident+2,' ');
					display(root->son2,ident+2);
					printf("%*cSEMI\n",ident+2,' ');
					break;
				case(STMT4_pro):
					printf("%*cStmt:   (%d)\n",ident,' ',root->line);
					printf("%*cif\n",ident+2,' ');
					printf("%*cLP\n",ident+2,' ');
					display(root->son1,ident+2);
					printf("%*cRP\n",ident+2,' ');
					display(root->son2,ident+2);
					break;
				case(STMT5_pro):
					printf("%*cStmt:   (%d)\n",ident,' ',root->line);
					printf("%*cif\n",ident+2,' ');
					printf("%*cLP\n",ident+2,' ');
					display(root->son1,ident+2);
					printf("%*cRP\n",ident+2,' ');
					display(root->son2,ident+2);
					printf("%*celse\n",ident+2,' ');
					display(root->son3,ident+2);
					break;
				case(STMT6_pro):
					printf("%*cStmt:   (%d)\n",ident,' ',root->line);
					printf("%*cwhile\n",ident+2,' ');
					printf("%*cLP\n",ident+2,' ');
					display(root->son1,ident+2);
					printf("%*cRP\n",ident+2,' ');
					display(root->son2,ident+2);
					break;
				default:
					puts("unexpected error: wierd statement.treefuncs.c:424");
			}
			break;
		}
		case(FUNDEC_type):
		{
			if(root->ProductionType == FUNDEC1_pro)
			{
				printf("%*cFunDec:   (%d)\n",ident,' ',root->line);
				printf("%*cID: %s\n",ident+2,' ',root->info.ID);
				printf("%*cLP\n",ident+2,' ');
				display(root->son1,ident+2);
				printf("%*cRP\n",ident+2,' ');
			}
			else if(root->ProductionType == FUNDEC2_pro)
			{
				printf("%*cFunDec:   (%d)\n",ident,' ',root->line);
				printf("%*cID: %s\n",ident+2,' ',root->info.ID);
				printf("%*cLP\n",ident+2,' ');
				printf("%*cRP\n",ident+2,' ');
			}
			break;
		}
		case(VARLIST_type):
		{
			if(root->ProductionType == VARLIST1_pro)
			{
				printf("%*cVarList:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cCOMMA\n",ident+2,' ');
				display(root->son3,ident+2);
			}
			else if(root->ProductionType == VARLIST2_pro)
			{
				printf("%*cVarList:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
			}
			break;
		}
		case(PARAMDEC_type):
		{
			if(root->ProductionType == PARAMDEC_pro)
			{
				printf("%*cParamDec:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				display(root->son2,ident+2);
			}
			else
				puts("unexpected error:treefuncs.c:472");
			break;
		}
		case(PROGRAM_type):
		{
			if(root->ProductionType == PROGRAM_pro)
			{
				printf("%*cProgram:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
			}
			else
				puts("unexpected error:treefuncs.c:472");
			break;
		}
		case(EXTDEFLIST_type):
		{
			if(root->ProductionType == EXTDEFLIST_pro)
			{
				printf("%*cExtDefList:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				display(root->son2,ident+2);
			}
			else if(root->ProductionType == EXTDEFLIST_empty)
			{
				//printf("%*cExtDefList:EXTDEFLIST_empty   (%d)\n",ident,' ',root->line);
				//printf("%*c---------------empty rule\n",ident+2,' ');
			}
			break;
		}
		case(EXTDEF_type):
		{
			switch(root->ProductionType)
			{
			case(EXTDEF1_pro):
				printf("%*cExtDef:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				display(root->son2,ident+2);
				printf("%*cSEMI\n",ident+2,' ');
				break;
			case(EXTDEF2_pro):
				printf("%*cExtDef:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cSEMI\n",ident+2,' ');
				break;
			case(EXTDEF3_pro):
				printf("%*cExtDef:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				display(root->son2,ident+2);
				display(root->son3,ident+2);
				break;
			default:
				puts("unexpected error:treefuncs.c:523");
			}
			break;
		}
		case(EXTDECLIST_type):
		{
			if(root->ProductionType == EXTDECLIST1_pro)
			{
				printf("%*cExtDecList:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
			}
			else if(root->ProductionType == EXTDECLIST2_pro)
			{
				printf("%*cExtDecList:   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+2);
				printf("%*cCOMMA\n",ident+2,' ');
				display(root->son3,ident+2);
			}
			break;
		}
		default:;
	}//end of nodetype switch
	return ;
}

void deletetree(pNODE root){
	if(root  == NULL)
		return;
	deletetree(root->son1);
	deletetree(root->son2);
	deletetree(root->son3);
	free(root);
	return;
}
