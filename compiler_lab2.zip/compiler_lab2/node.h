#ifndef NODE_H
#define NODE_H
#include "CalcAttri.h"
extern int LexErrNum;
typedef struct node{
    int nodetype;//decide the actions taken
    int ProductionType;//decide which production it use
    union {//info union used to store the info that the production has inherently
        char ID[32];
        int inum;
        float fnum;
    }info;
    struct node *son1;//max number of son is 3
    struct node *son2;
    struct node *son3;
    int line;//used only to show the line
    /***///transport values
    int offset;
    SYMBOLPOINTER pointer;
    /*******/
    /***///exp attribute transport values
    SYMBOLPOINTER SymbolBounded;//used to bound the variable
    int TypeOrder;//the TypeOrder
    int ValueType;//the single variable or array or right value only
    /*******/
}NODE,*pNODE;
pNODE newtree(pNODE son1,pNODE son2,pNODE son3,int nodetype,int productiontype,char *ID,int line);
void display(pNODE root,int ident);
void deletetree(pNODE root);



typedef enum NODETYPE {
	START_type = 0,EXP_type = 1,ARGS_type = 2,VARDEC_type = 3,DEC_type = 4,
	DECLIST_type = 5,TAG_type = 6,OPTTAG_type = 7,STRUCTSPECIFIER_type = 8,
	SPECIFIER_type = 9,DEF_type = 10,DEFLIST_type = 11,COMPST_type = 12,STMTLIST_type = 13,STMT_type = 14,
	FUNDEC_type = 15,VARLIST_type = 16,PARAMDEC_type = 17,
	PROGRAM_type =18,EXTDEFLIST_type = 19,EXTDEF_type =20,EXTDECLIST_type =21,
	ERROR_type =22
}NODETYPE;

typedef enum ExpressionsPro
{
	ASSIGNOP_pro,AND_pro,OR_pro,
	/*relop pros*/EBIG_pro,ESMALL_pro,BIG_pro,SMALL_pro,EQUAL_pro,NEQUAL_pro,
	PLUS_pro,MINUS_pro,STAR_pro,DIV_pro,
	LPRPe_pro,SINGLEMINUS_pro,NOT_pro,
	IDFunctionHasArgs_pro,IDFunctionNoArgs_pro,
	MATRIX_pro,DOT_pro,
	IDVar_pro,INT_pro,FLOAT_pro
} ExpPro;

typedef enum ArgsPro
{
	ARGS1_pro,ARGS2_pro
}ArgsPro;

typedef enum  VarDecPro
{
	VARDEC1_pro,VARDEC2_pro
}VarDecPro;

typedef enum  DecPro
{
	DEC1_pro,DEC2_pro
}DecPro;

typedef enum SpecifiersPro
{
	TYPEINT_pro,TYPEFLOAT_pro,
	SPECIFIER3_pro
}SpecifiersPro;

typedef enum StructSpecifierPro{
	STRUCTSPECIFIER1_pro,STRUCTSPECIFIER2_pro
} StructSpecifierPro;

typedef enum OptTagPro{
	OPTTAG_pro,OPTTAG_empty
}OptTagPro;
typedef enum Error_pro{
	ERROR_pro
}Error_pro;
typedef enum TagPro{
	TAG_pro
}TagPro;

typedef enum DecListPro{
	DECLIST1_pro,DECLIST2_pro
}DecListPro;

typedef enum DefPro{
	DEF_pro
}DefPro;

typedef enum  DefListPro
{
	DEFLIST_pro,DEFLIST_empty
}DefListPro;

typedef enum CompStPro
{
	COMPST_pro
}CompStPro;

typedef enum StmtListPro
{
	STMTLIST_pro,STMTLIST_empty
}StmtListPro;

typedef enum StmtPro
{
	STMT1_pro,STMT2_pro,STMT3_pro,STMT4_pro,STMT5_pro,STMT6_pro
}StmtPro;
typedef enum ProgramPro
{
	PROGRAM_pro
}ProgramPro;

typedef enum ExtDefListPro
{
	EXTDEFLIST_pro,EXTDEFLIST_empty
}ExtDefListPro;

typedef enum ExtDefPro
{
	EXTDEF1_pro,EXTDEF2_pro,EXTDEF3_pro
}ExtDefPro;

typedef enum ExtDecListPro
{
	EXTDECLIST1_pro,EXTDECLIST2_pro
}ExtDecListPro;

typedef enum FunDecPro
{
	FUNDEC1_pro,FUNDEC2_pro
}FunDecPro;

typedef enum VarListPro
{
	VARLIST1_pro,VARLIST2_pro
}VarListPro;

typedef enum  ParamDecPro
{
	PARAMDEC_pro
}ParamDecPro;



extern pNODE head;
void visit(pNODE root);

#endif
