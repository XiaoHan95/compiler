#include "node.h"
#include "compiler.tab.h"
#include "stdio.h"
#include "stdlib.h"
pNODE newtree(pNODE son1,pNODE son2,pNODE son3,int nodetype,int productiontype,char *ID,int line){
	pNODE a = (pNODE)malloc(sizeof(NODE));
	if(!a)
	{
		puts("unexpected error: no space for new node of the tree. treefuncs.c:7");
		exit(-1);
	}
	a->son1 = son1;
	a->son2 = son2;
	a->son3 = son3;
	a->nodetype = nodetype;
	a->ProductionType = productiontype;
	a->line = line;
	//we need to copy the values from ID into the union of the node,so 32 times of assign value needed
	int i = 0;
	if(ID == NULL)
		while(i <32)
		{
			a->info.ID[i] = '\0';
			i++;
		}
	else
		while(i < 32)
		{
			a->info.ID[i] = ID[i];
			i++;
		}
	return a;
}

void display(pNODE root,int ident){
	int identvar = 4;
	if(root == NULL)
	{
		puts("unexpected error:the head is null. debugfuncs:display");
		return;
	}
	switch(root->nodetype)
	{
		case(ERROR_type):
		{
			printf("%*cerror:ERROR_pro\n",ident,' ');
			break;
		}
		case(START_type):
		{
			printf("%*cstart:START_type\n",ident,' ');
			//puts("son1");
			display(root->son1,ident);
			//puts("son2");
			display(root->son2,ident);
			//puts("son3");
			display(root->son3,ident);
			break;			
		}

		case(EXP_type):
		{
			switch(root->ProductionType)
			{
			case(INT_pro):
				printf("%*cexp:INT_pro   (%d)\n",ident,' ',root->line);
				printf("%*cINT:%d\n",ident+identvar,' ',root->info.inum);
				break;
			case(FLOAT_pro):
				printf("%*cexp:FLOAT_pro   (%d)\n",ident,' ',root->line);
				printf("%*cFLOAT:%f\n",ident+identvar,' ',root->info.fnum);
				break;
			case (PLUS_pro):
				printf("%*cexp:PLUS_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c+\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;
			case(MINUS_pro):
				printf("%*cexp:MINUS_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c-\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;
			case(STAR_pro):
				printf("%*cexp:STAR_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c*\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;
			case(DIV_pro):
				printf("%*cexp:DIV_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c/\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;	
			case(EBIG_pro):
				printf("%*cexp:EBIG_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c>=\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;
			case(ESMALL_pro):
				printf("%*cexp:ESMALL_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c<=\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;
			case(BIG_pro):
				printf("%*cexp:BIG_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c>\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;			
			case(SMALL_pro):
				printf("%*cexp:SMALL_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c<\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;
			case(EQUAL_pro):
				printf("%*cexp:EQUAL_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c==\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;
			case(NEQUAL_pro):
				printf("%*cexp:NEQUAL_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c!=\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;
			case(OR_pro):
				printf("%*cexp:OR_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c||\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;
			case(AND_pro):
				printf("%*cexp:AND_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c&&\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;
			case(ASSIGNOP_pro):
				printf("%*cexp:ASSIGNOP_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c=\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;		
			case(LPRPe_pro):
				printf("%*cexp:LP_pro   (%d)\n",ident,' ',root->line);
				printf("%*c(\n",ident+identvar,' ');
				display(root->son2,ident+identvar);
				printf("%*c)\n",ident+identvar,' ');
				break;		
			case(SINGLEMINUS_pro):
				printf("%*cexp:SINGLEMINUS_pro   (%d)\n",ident,' ',root->line);
				printf("%*c-\n",ident+identvar,' ');	
				display(root->son2,ident+identvar);
				break;
			case(NOT_pro):
				printf("%*cexp:NOT_pro   (%d)\n",ident,' ',root->line);
				printf("%*c!\n",ident+identvar,' ');	
				display(root->son2,ident+identvar);
				break;	
			case(IDVar_pro):
				printf("%*cexp:IDVar_pro   (%d)\n",ident,' ',root->line);
				printf("%*cID:%s\n",ident+identvar,' ',root->info.ID);
				break;		
			case(IDFunctionNoArgs_pro):
				printf("%*cexp:IDFunction_pro   (%d)\n",ident,' ',root->line);
				printf("%*c%s\n",ident+identvar,' ',root->info.ID);
				printf("%*c(\n",ident+identvar,' ');
				printf("%*c)\n",ident+identvar,' ');	
				break;		
			case(DOT_pro):
				printf("%*cexp:DOT_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c.\n",ident+identvar,' ');
				printf("%*c%s\n",ident+identvar,' ',root->info.ID);
				break;
			case(MATRIX_pro):
				printf("%*cexp:MATRIX_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c[\n",ident+identvar,' ');
				display(root->son2,ident+identvar);
				printf("%*c]\n",ident+identvar,' ');
				break;
			case(IDFunctionHasArgs_pro):
				printf("%*cexp:IDFunctionHasArgs_pro   (%d)\n",ident,' ',root->line);
				printf("%*c%s\n",ident+identvar,' ',root->info.ID);
				printf("%*c(\n",ident+identvar,' ');
				display(root->son1,ident+identvar);
				printf("%*c)\n",ident+identvar,' ');
				break;
			default:
				puts("unexpected error: unknown pro in EXP_type node. treefuncs.c:173");		
			}//end of EXP_type switch
			break;
		}//end of EXP_type case
		case(ARGS_type):
		{
			switch(root->ProductionType)
			{
			case(ARGS1_pro):
				printf("%*cArgs:ARGS1_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c,\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;
			case(ARGS2_pro):
				printf("%*cArgs:ARGS2_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				break;
			default:
				puts("unexpected error: unknown pro in ARGS_type node. treefuncs.c:192");
			}
			break;
		}

		case(DEC_type):
		{
			switch(root->ProductionType)
			{
			case(DEC1_pro):
				printf("%*cDec:Dec1_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				break;
			case(DEC2_pro):
				printf("%*cDec:Dec2_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c=\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
				break;
			default:
				puts("unexpected error: unknown pro in DEC_type node. treefuncs.c:219");
			}
			break;
		}
		case(VARDEC_type):
		{
			switch(root->ProductionType)
			{
			case(VARDEC1_pro):
				printf("%*cVarDec:VARDEC1_pro   (%d)\n",ident,' ',root->line);
				printf("%*cID:%s\n", ident+identvar,' ',root->info.ID);
				break;
			case(VARDEC2_pro):
				printf("%*cVarDec:VARDEC2_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c[\n",ident+identvar,' ');
				printf("%*cINT:%d\n",ident+identvar,' ',root->info.inum);
				printf("%*c]\n",ident+identvar,' ');
				break;
			default:
				puts("unexpected error: unknown pro in VARDEC_type node. treefuncs.c:241");
			}	
			break;		
		}
		case(DECLIST_type):
		{
			if(root->ProductionType == DECLIST1_pro)
			{
				printf("%*cDecList:DECLIST1_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
			}
			else if(root->ProductionType == DECLIST2_pro)
			{
				printf("%*cDecList:DECLIST2_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c,\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
			}
			else
				puts("unexpected error: unknown pro in DECLIST_type node. treefuncs.c:267");
			break;
		}
		case(SPECIFIER_type):
		{
			switch(root->ProductionType)
			{
			case(TYPEINT_pro):
				printf("%*cSpecifier:TYPEINT_pro   (%d)\n",ident,' ',root->line);
				printf("%*cTYPE:  int\n",ident+identvar,' ');
				break;
			case(TYPEFLOAT_pro):
				printf("%*cSpecifier:TYPEFLOAT_pro   (%d)\n",ident,' ',root->line);
				printf("%*cTYPE:  float\n",ident+identvar,' ');
				break;	
			case(SPECIFIER3_pro):
				printf("%*cSpecifier:SPECIFIER3_pro   (%d)\n",ident,' ',root->line);	
				display(root->son1,ident+identvar);
				break;
			default:
				puts("unexpected error: unknown pro in SPECIFIER_type node. treefuncs.c:287");
			}
			break;
		}
		case(STRUCTSPECIFIER_type):
		{
			if(root->ProductionType == STRUCTSPECIFIER1_pro)
			{
				printf("%*cStructSpecifier:STRUCTSPECIFIER1_pro   (%d)\n",ident,' ',root->line);	
				printf("%*cstruct\n",ident+identvar,' ');
				display(root->son1,ident+identvar);
				printf("%*c{\n",ident+identvar,' ');
				display(root->son2,ident+identvar);
				printf("%*c}\n",ident+identvar,' ');
			}
			else if(root->ProductionType == STRUCTSPECIFIER2_pro)
			{
				printf("%*cStructSpecifier:STRUCTSPECIFIER2_pro   (%d)\n",ident,' ',root->line);	
				printf("%*cstruct\n",ident+identvar,' ');
				display(root->son2,ident+identvar);
			}
			else
				puts("unexpected error: unknown pro in STRUCTSPECIFIER_type node. treefuncs.c:309");
			break;
		}
		case(OPTTAG_type):
		{
			if(root->ProductionType == OPTTAG_pro)
			{
				printf("%*cOptTag:OPTTAG_pro   (%d)\n",ident,' ',root->line);
				printf("%*cID: %s\n",ident+identvar,' ',root->info.ID);				
			}
			else if(root->ProductionType == OPTTAG_empty)
			{
				printf("%*cOptTag:OPTTAG_empty   (%d)\n",ident,' ',root->line);
				printf("%*c---------------empty rule\n",ident+identvar,' ');
			}
			break;
		}
		case(TAG_type):
		{
			printf("%*cTag:TAG_pro   (%d)\n",ident,' ',root->line);
			printf("%*cID: %s\n",ident+identvar,' ',root->info.ID);
			break;			
		}
		case(DEF_type):
		{
			printf("%*cDef:DEF_pro   (%d)\n",ident,' ',root->line);
			display(root->son1,ident+identvar);
			display(root->son2,ident+identvar);
			printf("%*c;\n",ident+identvar,' ');
			break;
		}
		case(DEFLIST_type):
		{
			if(root->ProductionType == DEFLIST_pro)
			{
				printf("%*cDefList:DEFLIST_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				display(root->son2,ident+identvar);				
			}
			else if(root->ProductionType == DEFLIST_empty)
			{
				printf("%*cDefList:DEFLIST_empty   (%d)\n",ident,' ',root->line);
				printf("%*c---------------empty rule\n",ident+identvar,' ');
			}
			break;
		}
		case(COMPST_type):
		{
			printf("%*cCompSt:COMPST_pro   (%d)\n",ident,' ',root->line);
			printf("%*c{\n",ident+identvar,' ');
			display(root->son1,ident+identvar);
			display(root->son2,ident+identvar);
			printf("%*c}\n",ident+identvar,' ');
			break;
		}
		case(STMTLIST_type):
		{
			if(root->ProductionType == STMTLIST_pro)
			{
				printf("%*cStmtList:STMTLIST_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				display(root->son2,ident+identvar);
			}	
			else if(root->ProductionType == STMTLIST_empty)
			{
				printf("%*cStmtList:STMTLIST_empty   (%d)\n",ident,' ',root->line);
				printf("%*c---------------empty rule\n",ident+identvar,' ');
			}
			break;
		}
		case(STMT_type):
		{
			switch(root->ProductionType)
			{
				case(STMT1_pro):
					printf("%*cStmt:STMT1_pro   (%d)\n",ident,' ',root->line);
					display(root->son1,ident+identvar);
					printf("%*c;\n",ident+identvar,' ');
					break;
				case(STMT2_pro):
					printf("%*cStmt:STMT2_pro   (%d)\n",ident,' ',root->line);
					display(root->son1,ident+identvar);
					break;
				case(STMT3_pro):
					printf("%*cStmt:STMT3_pro   (%d)\n",ident,' ',root->line);
					printf("%*creturn\n",ident+identvar,' ');
					display(root->son2,ident+identvar);
					printf("%*c;\n",ident+identvar,' ');
					break;
				case(STMT4_pro):
					printf("%*cStmt:STMT4_pro   (%d)\n",ident,' ',root->line);
					printf("%*cif\n",ident+identvar,' ');
					printf("%*c(\n",ident+identvar,' ');
					display(root->son1,ident+identvar);
					printf("%*c)\n",ident+identvar,' ');
					display(root->son2,ident+identvar);
					break;
				case(STMT5_pro):
					printf("%*cStmt:STMT5_pro   (%d)\n",ident,' ',root->line);
					printf("%*cif\n",ident+identvar,' ');
					printf("%*c(\n",ident+identvar,' ');
					display(root->son1,ident+identvar);
					printf("%*c)\n",ident+identvar,' ');
					display(root->son2,ident+identvar);
					printf("%*celse\n",ident+identvar,' ');
					display(root->son3,ident+identvar);
					break;
				case(STMT6_pro):
					printf("%*cStmt:STMT6_pro   (%d)\n",ident,' ',root->line);
					printf("%*cwhile\n",ident+identvar,' ');
					printf("%*c(\n",ident+identvar,' ');
					display(root->son1,ident+identvar);
					printf("%*c)\n",ident+identvar,' ');
					display(root->son2,ident+identvar);
					break;		
				default:		
					puts("unexpected error: wierd statement.treefuncs.c:424");	
			}
			break;
		}
		case(FUNDEC_type):
		{
			if(root->ProductionType == FUNDEC1_pro)
			{
				printf("%*cFunDec:FUNDEC1_pro   (%d)\n",ident,' ',root->line);
				printf("%*cID: %s\n",ident+identvar,' ',root->info.ID);
				printf("%*c(\n",ident+identvar,' ');
				display(root->son1,ident+identvar);
				printf("%*c)\n",ident+identvar,' ');
			}	
			else if(root->ProductionType == FUNDEC2_pro)
			{
				printf("%*cFunDec:FUNDEC2_pro   (%d)\n",ident,' ',root->line);
				printf("%*cID: %s\n",ident+identvar,' ',root->info.ID);
				printf("%*c(\n",ident+identvar,' ');
				printf("%*c)\n",ident+identvar,' ');
			}
			break;
		}
		case(VARLIST_type):
		{
			if(root->ProductionType == VARLIST1_pro)
			{
				printf("%*cVarList:VARLIST1_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c,\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
			}	
			else if(root->ProductionType == VARLIST2_pro)
			{
				printf("%*cVarList:VARLIST2_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
			}
			break;
		}
		case(PARAMDEC_type):
		{
			if(root->ProductionType == PARAMDEC_pro)
			{
				printf("%*cParamDec:PARAMDEC_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				display(root->son2,ident+identvar);
			}
			else
				puts("unexpected error:treefuncs.c:472");
			break;
		}
		case(PROGRAM_type):
		{
			if(root->ProductionType == PROGRAM_pro)
			{
				printf("%*cProgram:PROGRAM_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
			}
			else
				puts("unexpected error:treefuncs.c:472");
			break;
		}
		case(EXTDEFLIST_type):
		{
			if(root->ProductionType == EXTDEFLIST_pro)
			{
				printf("%*cExtDefList:EXTDEFLIST_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				display(root->son2,ident+identvar);
			}	
			else if(root->ProductionType == EXTDEFLIST_empty)
			{
				printf("%*cExtDefList:EXTDEFLIST_empty   (%d)\n",ident,' ',root->line);
				printf("%*c---------------empty rule\n",ident+identvar,' ');
			}		
			break;
		}
		case(EXTDEF_type):
		{
			switch(root->ProductionType)
			{
			case(EXTDEF1_pro):
				printf("%*cExtDef:EXTDEF1_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				display(root->son2,ident+identvar);
				printf("%*c;\n",ident+identvar,' ');
				break;
			case(EXTDEF2_pro):
				printf("%*cExtDef:EXTDEF2_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c;\n",ident+identvar,' ');
				break;
			case(EXTDEF3_pro):
				printf("%*cExtDef:EXTDEF3_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				display(root->son2,ident+identvar);
				display(root->son3,ident+identvar);
				break;
			default:
				puts("unexpected error:treefuncs.c:identvar23");
			}
			break;
		}
		case(EXTDECLIST_type):
		{
			if(root->ProductionType == EXTDECLIST1_pro)
			{
				printf("%*cExtDecList:EXTDECLIST1_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
			}	
			else if(root->ProductionType == EXTDECLIST2_pro)
			{
				printf("%*cExtDecList:EXTDECLIST2_pro   (%d)\n",ident,' ',root->line);
				display(root->son1,ident+identvar);
				printf("%*c,\n",ident+identvar,' ');
				display(root->son3,ident+identvar);
			}
			break;
		}
		default:;
	}//end of nodetype switch
	return ;
}

void deletetree(pNODE root){
	if(root  == NULL)
		return;
	deletetree(root->son1);
	deletetree(root->son2);
	deletetree(root->son3);
	free(root);
	return;
}
