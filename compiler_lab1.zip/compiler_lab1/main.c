struct outerstruct
{
	int a;
	int aa[2];
	struct nestedouterstruct
	{
		float a;
		float aa[2];
	}b,bb[2][3];
}out1;
struct outerstruct out2;

int main()
{
	struct outerstruct in1;
	struct innerstrcut {
		int a;
		int aa[2];
		struct nestedinnerstruct
		{
			float a;
			float aa[2];
		}b,bb[5][6];
	}in2,in3[7][7];
	return 0;
}